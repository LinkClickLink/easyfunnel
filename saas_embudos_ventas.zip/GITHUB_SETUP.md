
# 🐙 Guía para Crear tu Repositorio en GitHub

Esta guía te llevará paso a paso para crear tu repositorio en GitHub y configurar tu SaaS para producción.

## 📋 Pasos para crear el repositorio

### 1. Crear el repositorio en GitHub

1. Ve a [GitHub](https://github.com) e inicia sesión
2. Haz clic en el botón **"New"** (verde) o ve a https://github.com/new
3. Completa los campos:
   - **Repository name**: `saas-embudos-ventas` (o el nombre que prefieras)
   - **Description**: "SaaS completo para crear y gestionar embudos de ventas digitales"
   - **Visibility**: Elige si quieres que sea público o privado
   - ❌ **NO marques** "Add a README file" (ya tenemos uno)
   - ❌ **NO marques** "Add .gitignore" (ya tenemos uno)
   - ❌ **NO marques** "Choose a license" (ya tenemos uno)

4. Haz clic en **"Create repository"**

### 2. Subir el código al repositorio

Desde tu terminal, navega a la carpeta del proyecto y ejecuta:

```bash
cd /home/ubuntu/saas_embudos_ventas

# Inicializar git si no está inicializado
git init

# Añadir todos los archivos
git add .

# Hacer el primer commit
git commit -m "feat: SaaS completo de embudos de ventas digitales

- Constructor de embudos visual con 3 pasos
- Gestión de productos digitales con AWS S3  
- CRM integrado con pipeline Kanban
- Panel de configuración completo
- Área de miembros para clientes
- Sistema de emails automatizados
- Integración con Stripe para pagos
- Dashboard con estadísticas en tiempo real"

# Conectar con tu repositorio remoto (reemplaza TU-USUARIO con tu username de GitHub)
git remote add origin https://github.com/TU-USUARIO/saas-embudos-ventas.git

# Subir el código
git branch -M main
git push -u origin main
```

### 3. Configurar Secrets de GitHub (para CI/CD)

Si quieres configurar deployment automático:

1. Ve a tu repositorio en GitHub
2. Click en **Settings** → **Secrets and variables** → **Actions**
3. Añade estos secrets:

```
DATABASE_URL=postgresql://usuario:password@host:5432/db
NEXTAUTH_SECRET=tu-secret-super-seguro-de-32-caracteres
AWS_ACCESS_KEY_ID=tu-access-key
AWS_SECRET_ACCESS_KEY=tu-secret-key
STRIPE_SECRET_KEY=sk_live_...
```

## 🚀 Instrucciones para instalar en tu servidor

### Opción 1: Script Automático (Recomendado)

```bash
# En tu servidor, como root o con sudo
wget https://raw.githubusercontent.com/TU-USUARIO/saas-embudos-ventas/main/deploy.sh
chmod +x deploy.sh
./deploy.sh
```

### Opción 2: Instalación Manual

#### 1. Preparar el servidor

```bash
# Actualizar sistema
sudo apt update && sudo apt upgrade -y

# Instalar Node.js 18
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt-get install -y nodejs

# Instalar Yarn
npm install -g yarn

# Instalar PostgreSQL
sudo apt install postgresql postgresql-contrib

# Instalar PM2
npm install -g pm2

# Instalar Nginx
sudo apt install nginx
```

#### 2. Configurar base de datos

```bash
sudo -u postgres createdb embudos_ventas
sudo -u postgres createuser --interactive
# Seguir las instrucciones para crear el usuario
```

#### 3. Clonar y configurar aplicación

```bash
cd /var/www
git clone https://github.com/TU-USUARIO/saas-embudos-ventas.git
cd saas-embudos-ventas

# Ejecutar script de configuración
./scripts/setup.sh

# Configurar variables de entorno
cp .env.example .env
nano .env
```

#### 4. Construir y ejecutar

```bash
cd app
yarn build
pm2 start yarn --name "embudos-saas" -- start
pm2 startup
pm2 save
```

## 🔧 Configuraciones necesarias antes de usar

### 1. AWS S3 Setup

```bash
# Crear bucket S3
aws s3 mb s3://tu-bucket-embudos

# Configurar política de bucket
aws s3api put-bucket-cors --bucket tu-bucket-embudos --cors-configuration file://cors.json
```

Archivo `cors.json`:
```json
{
    "CORSRules": [
        {
            "AllowedHeaders": ["*"],
            "AllowedMethods": ["GET", "PUT", "POST", "DELETE"],
            "AllowedOrigins": ["https://tu-dominio.com"],
            "ExposeHeaders": []
        }
    ]
}
```

### 2. Stripe Setup

1. Crear cuenta en [Stripe](https://stripe.com)
2. Ir a **Developers** → **API Keys**
3. Copiar las claves y añadirlas al `.env`:

```env
STRIPE_PUBLISHABLE_KEY=pk_live_...
STRIPE_SECRET_KEY=sk_live_...
```

### 3. Configurar dominio

#### DNS Records
```
Type: A
Name: @
Value: IP_DE_TU_SERVIDOR

Type: A  
Name: www
Value: IP_DE_TU_SERVIDOR
```

#### SSL con Let's Encrypt
```bash
sudo apt install certbot python3-certbot-nginx
sudo certbot --nginx -d tu-dominio.com -d www.tu-dominio.com
```

## 🔒 Variables de entorno críticas

Asegúrate de configurar estas variables en tu `.env`:

```env
# Base de datos
DATABASE_URL="postgresql://usuario:password@localhost:5432/embudos_ventas"

# NextAuth
NEXTAUTH_URL="https://tu-dominio.com"
NEXTAUTH_SECRET="secret-super-seguro-de-32-caracteres-minimo"

# AWS S3
AWS_REGION="us-west-2"
AWS_BUCKET_NAME="tu-bucket-embudos"
AWS_ACCESS_KEY_ID="AKIA..."
AWS_SECRET_ACCESS_KEY="tu-secret-key"

# Stripe
STRIPE_PUBLISHABLE_KEY="pk_live_..."
STRIPE_SECRET_KEY="sk_live_..."

# Email (opcional)
SMTP_HOST="smtp.gmail.com"
SMTP_PORT="587"
SMTP_USER="tu-email@gmail.com"
SMTP_PASS="tu-app-password"
```

## 📊 Comandos útiles de mantenimiento

```bash
# Ver logs de la aplicación
pm2 logs embudos-saas

# Reiniciar aplicación
pm2 restart embudos-saas

# Ver estadísticas
pm2 monit

# Backup manual
./scripts/backup.sh

# Actualizar aplicación
git pull origin main
cd app && yarn install && yarn build
pm2 restart embudos-saas
```

## 🎯 Siguientes pasos después de la instalación

1. **Acceder a la aplicación**: `https://tu-dominio.com`
2. **Registrar tu cuenta de admin**
3. **Configurar tu primer embudo**
4. **Subir tus productos digitales**
5. **Personalizar la configuración**
6. **Probar el flujo completo**

## 📞 Soporte

Si tienes problemas durante la instalación:

1. **Revisa los logs**:
   ```bash
   pm2 logs embudos-saas
   tail -f /var/log/nginx/error.log
   ```

2. **Problemas comunes** están documentados en `INSTALLATION.md`

3. **Crea un issue** en GitHub si encuentras un bug

4. **Únete a la comunidad** en Discord para ayuda

## ✅ Checklist de verificación

Después de la instalación, verifica:

- [ ] La aplicación carga en tu dominio
- [ ] Puedes registrar una cuenta
- [ ] El dashboard funciona correctamente
- [ ] Puedes subir un archivo de prueba
- [ ] Los emails se envían (revisa spam)
- [ ] El área de miembros funciona
- [ ] Los pagos de Stripe funcionan en modo test
- [ ] El SSL está configurado correctamente
- [ ] Los backups automáticos funcionan

¡Felicidades! Tu SaaS ya está funcionando 🎉
