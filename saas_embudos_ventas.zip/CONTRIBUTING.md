
# 🤝 Guía de Contribución

¡Gracias por tu interés en contribuir al SaaS de Embudos de Ventas! Tu ayuda es muy valiosa para mejorar este proyecto.

## 📋 Tabla de Contenidos

- [Código de Conducta](#código-de-conducta)
- [¿Cómo puedo contribuir?](#cómo-puedo-contribuir)
- [Configuración del entorno de desarrollo](#configuración-del-entorno-de-desarrollo)
- [Proceso de desarrollo](#proceso-de-desarrollo)
- [Estándares de código](#estándares-de-código)
- [Proceso de Pull Request](#proceso-de-pull-request)

## 📖 Código de Conducta

Este proyecto se adhiere al [Código de Conducta](CODE_OF_CONDUCT.md). Al participar, se espera que mantengas este código.

## 🚀 ¿Cómo puedo contribuir?

### 🐛 Reportar Bugs

Los bugs se rastrean como [GitHub issues](https://github.com/tu-usuario/saas-embudos-ventas/issues). Antes de crear un bug report:

1. **Verifica si el bug ya fue reportado** buscando en los issues existentes
2. **Determina qué repositorio** debería recibir el problema
3. **Recolecta información** sobre el bug

Cuando creates un bug report, incluye:

- **Título claro y descriptivo**
- **Pasos exactos para reproducir** el problema
- **Comportamiento esperado vs actual**
- **Screenshots** si aplica
- **Información del entorno** (OS, versión de Node.js, etc.)

### 💡 Sugerir Mejoras

Las mejoras también se rastrean como [GitHub issues](https://github.com/tu-usuario/saas-embudos-ventas/issues). Al crear una sugerencia de mejora:

- **Usa un título claro y descriptivo**
- **Describe el comportamiento actual** y **explica qué comportamiento esperabas** ver
- **Explica por qué esta mejora sería útil**
- **Lista algunos otros proyectos** donde esta mejora existe

### 🔧 Tu Primera Contribución de Código

¿No estás seguro por dónde empezar? Puedes comenzar buscando issues etiquetados como:

- `good first issue` - issues que requieren pocas líneas de código
- `help wanted` - issues que requieren un poco más de trabajo

## 🛠️ Configuración del entorno de desarrollo

1. **Fork el repositorio** y clónalo localmente
2. **Instala las dependencias**:
   ```bash
   cd app
   yarn install
   ```
3. **Configura tu base de datos** siguiendo las instrucciones en [INSTALLATION.md](INSTALLATION.md)
4. **Copia las variables de entorno**:
   ```bash
   cp .env.example .env
   ```
5. **Ejecuta las migraciones**:
   ```bash
   yarn prisma migrate dev
   ```
6. **Inicia el servidor de desarrollo**:
   ```bash
   yarn dev
   ```

## 🔄 Proceso de desarrollo

1. **Crea una rama** para tu feature:
   ```bash
   git checkout -b feature/descripcion-corta
   ```

2. **Haz tus cambios** siguiendo los estándares de código

3. **Escribe tests** para tu código cuando sea apropiado

4. **Ejecuta los tests** para asegurar que no rompiste nada:
   ```bash
   yarn test
   yarn lint
   yarn tsc --noEmit
   ```

5. **Commit tus cambios** usando mensajes descriptivos:
   ```bash
   git commit -m "feat: añadir funcionalidad X"
   ```

## 📝 Estándares de código

### JavaScript/TypeScript

- Usamos **TypeScript** para todo el código
- Seguimos las reglas de **ESLint** configuradas en el proyecto
- Usamos **Prettier** para formateo automático
- Todas las funciones públicas deben tener **JSDoc**

### Estructura de archivos

```
app/
├── components/          # Componentes React reutilizables
├── pages/              # Páginas de Next.js
├── api/                # API Routes
├── lib/                # Utilidades y configuración
├── hooks/              # Custom React hooks
├── types/              # Definiciones de tipos TypeScript
└── styles/             # Estilos CSS/Tailwind
```

### Convenciones de nombres

- **Archivos**: `kebab-case.tsx`
- **Componentes**: `PascalCase`
- **Variables/funciones**: `camelCase`
- **Constantes**: `SCREAMING_SNAKE_CASE`
- **Tipos**: `PascalCase`

### Commits

Usamos [Conventional Commits](https://www.conventionalcommits.org/):

```
<type>[optional scope]: <description>

[optional body]

[optional footer(s)]
```

Tipos válidos:
- `feat`: Nueva funcionalidad
- `fix`: Bug fix
- `docs`: Cambios en documentación
- `style`: Formateo, punto y comas faltantes, etc
- `refactor`: Refactoring de código
- `test`: Añadir tests faltantes
- `chore`: Actualizaciones de build tasks, package manager configs, etc

## 🔀 Proceso de Pull Request

1. **Asegurate** de que tu código sigue los estándares
2. **Actualiza la documentación** si es necesario
3. **Añade tests** para funcionalidad nueva
4. **Ejecuta todos los tests** y asegurate de que pasen
5. **Crea el Pull Request** con:
   - Título descriptivo
   - Descripción detallada de los cambios
   - Referencias a issues relacionados
   - Screenshots si hay cambios visuales

### Template de Pull Request

```markdown
## Descripción
Descripción breve de los cambios realizados.

## Tipo de cambio
- [ ] Bug fix (non-breaking change which fixes an issue)
- [ ] New feature (non-breaking change which adds functionality)
- [ ] Breaking change (fix or feature that would cause existing functionality to not work as expected)
- [ ] Documentation update

## ¿Cómo se ha probado?
Describe las pruebas que ejecutaste para verificar tus cambios.

## Checklist:
- [ ] Mi código sigue las pautas de estilo de este proyecto
- [ ] He realizado una auto-revisión de mi propio código
- [ ] He comentado mi código, particularmente en áreas difíciles de entender
- [ ] He realizado los cambios correspondientes a la documentación
- [ ] Mis cambios no generan nuevas advertencias
- [ ] He añadido pruebas que demuestran que mi corrección es efectiva o que mi función funciona
- [ ] Las pruebas unitarias nuevas y existentes pasan localmente con mis cambios
```

## 🏷️ Versionado

Usamos [SemVer](http://semver.org/) para versionado:

- **MAJOR**: Cambios incompatibles de API
- **MINOR**: Funcionalidad nueva compatible hacia atrás
- **PATCH**: Bug fixes compatibles hacia atrás

## 📞 ¿Necesitas ayuda?

- Crea un [issue](https://github.com/tu-usuario/saas-embudos-ventas/issues)
- Únete a nuestro [Discord](https://discord.gg/embudos)
- Envía un email a: contribute@embudos-digitales.com

¡Gracias por contribuir! 🎉
