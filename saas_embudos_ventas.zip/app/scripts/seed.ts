
import { PrismaClient } from '@prisma/client';
import bcrypt from 'bcryptjs';

const prisma = new PrismaClient();

async function main() {
  console.log('🌱 Iniciando seeding...');

  // Limpiar datos existentes
  await prisma.orderItem.deleteMany();
  await prisma.order.deleteMany();
  await prisma.contact.deleteMany();
  await prisma.product.deleteMany();
  await prisma.funnelPage.deleteMany();
  await prisma.funnel.deleteMany();
  await prisma.user.deleteMany();
  await prisma.coupon.deleteMany();
  await prisma.template.deleteMany();
  await prisma.emailNotification.deleteMany();

  console.log('✅ Datos anteriores eliminados');

  // Crear usuario de prueba con admin privileges
  const testUserPassword = await bcrypt.hash('johndoe123', 12);
  
  const testUser = await prisma.user.create({
    data: {
      email: 'john@doe.com',
      password: testUserPassword,
      firstName: 'John',
      lastName: 'Doe',
      companyName: 'Test Company',
      name: 'John Doe',
      hasPaidAccess: true,
      isActive: true,
    },
  });

  console.log('✅ Usuario de prueba creado');

  // Crear cupones de descuento
  await prisma.coupon.createMany({
    data: [
      {
        code: 'BIENVENIDO10',
        description: 'Descuento de bienvenida del 10%',
        discountType: 'PERCENTAGE',
        discountValue: 10,
        maxUses: 100,
        isActive: true,
        validTo: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000), // 30 días
      },
      {
        code: 'DESCUENTO5',
        description: 'Descuento fijo de 5€',
        discountType: 'FIXED_AMOUNT',
        discountValue: 5,
        minimumAmount: 20,
        maxUses: 50,
        isActive: true,
        validTo: new Date(Date.now() + 60 * 24 * 60 * 60 * 1000), // 60 días
      },
    ],
  });

  console.log('✅ Cupones creados');

  // Crear plantillas de páginas
  const landingTemplate = {
    name: 'Landing Profesional',
    description: 'Página de aterrizaje optimizada para conversión',
    category: 'conversion',
    pageType: 'LANDING' as const,
    content: {
      hero: {
        title: 'Transforma Tu Negocio Digital',
        subtitle: 'Descarga nuestro producto digital y lleva tu emprendimiento al siguiente nivel',
        buttonText: 'Obtener Ahora',
        image: 'https://images.unsplash.com/photo-1522202176988-66273c2fd55f?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80'
      },
      benefits: [
        'Acceso inmediato al contenido',
        'Garantía de satisfacción 30 días',
        'Soporte prioritario incluido',
        'Actualizaciones gratuitas de por vida'
      ],
      testimonials: [
        {
          text: 'Este producto cambió completamente mi forma de trabajar',
          author: 'María González',
          role: 'Emprendedora Digital'
        }
      ]
    },
    isFree: true,
    isActive: true,
  };

  const checkoutTemplate = {
    name: 'Checkout Optimizado',
    description: 'Página de pago con alta tasa de conversión',
    category: 'ecommerce',
    pageType: 'CHECKOUT' as const,
    content: {
      product: {
        name: 'Tu Producto Digital',
        price: 25,
        image: 'https://images.unsplash.com/photo-1553484771-cc0d9b8c2b33?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
        features: [
          'Descarga inmediata',
          'Formato PDF de alta calidad',
          'Acceso de por vida',
          'Soporte incluido'
        ]
      },
      guarantee: {
        text: 'Garantía de satisfacción de 30 días o te devolvemos tu dinero',
        icon: 'shield'
      }
    },
    isFree: true,
    isActive: true,
  };

  const thankYouTemplate = {
    name: 'Página de Gracias',
    description: 'Página de confirmación y acceso a productos',
    category: 'confirmation',
    pageType: 'THANK_YOU' as const,
    content: {
      message: {
        title: '¡Gracias por tu compra!',
        subtitle: 'Tu pedido ha sido procesado exitosamente',
        icon: 'check-circle'
      },
      nextSteps: [
        'Revisa tu email para la confirmación',
        'Accede al área de miembros',
        'Descarga tu producto',
        'Únete a nuestra comunidad'
      ],
      memberAccess: {
        title: 'Acceso al Área de Miembros',
        description: 'Usa las siguientes credenciales para acceder a tus productos',
        buttonText: 'Ir al Área de Miembros'
      }
    },
    isFree: true,
    isActive: true,
  };

  await prisma.template.createMany({
    data: [landingTemplate, checkoutTemplate, thankYouTemplate],
  });

  console.log('✅ Plantillas creadas');

  // Crear notificaciones de email
  await prisma.emailNotification.createMany({
    data: [
      {
        type: 'WELCOME',
        subject: '¡Bienvenido a Embudos Digitales!',
        content: `
          <h1>¡Bienvenido a Embudos Digitales!</h1>
          <p>Gracias por unirte a nosotros. Estás a punto de crear embudos de ventas que realmente convierten.</p>
          <p>Para comenzar, accede a tu dashboard y configura tu primer embudo.</p>
        `,
        isActive: true,
      },
      {
        type: 'ORDER_CONFIRMATION',
        subject: 'Confirmación de tu pedido',
        content: `
          <h1>¡Tu pedido ha sido confirmado!</h1>
          <p>Gracias por tu compra. Podrás descargar tus productos desde el área de miembros.</p>
          <p>Datos del pedido: {{orderNumber}}</p>
          <p>Total pagado: {{total}}€</p>
        `,
        isActive: true,
      },
      {
        type: 'DOWNLOAD_READY',
        subject: 'Tu producto está listo para descargar',
        content: `
          <h1>¡Tu producto ya está disponible!</h1>
          <p>Puedes descargarlo desde tu área de miembros usando el enlace que te enviamos.</p>
          <p>Si tienes algún problema, no dudes en contactarnos.</p>
        `,
        isActive: true,
      },
    ],
  });

  console.log('✅ Notificaciones de email creadas');

  console.log('🎉 Seeding completado exitosamente!');
}

main()
  .catch((e) => {
    console.error('❌ Error durante el seeding:', e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
