
import { redirect } from 'next/navigation';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import MembersArea from '@/components/members/members-area';

export default async function MembersPage() {
  const session = await getServerSession(authOptions);
  
  if (!session) {
    redirect('/auth/login?callbackUrl=/members');
  }

  // Here you would fetch member data from the database
  // For now, we'll pass mock data through the component

  return <MembersArea />;
}

export const metadata = {
  title: 'Área de Miembros - Embudos Digitales',
  description: 'Accede a todos tus productos digitales',
};
