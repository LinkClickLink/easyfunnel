
import { User, Funnel, Product, Order, Contact, Coupon } from "@prisma/client";

export interface UserWithFunnel extends User {
  funnel?: Funnel | null;
}

export interface FunnelWithDetails extends Funnel {
  pages: FunnelPage[];
  products: Product[];
  orders: Order[];
  contacts: Contact[];
  _count: {
    orders: number;
    contacts: number;
  };
}

export interface FunnelPage {
  id: string;
  type: 'LANDING' | 'CHECKOUT' | 'THANK_YOU' | 'MEMBER_AREA';
  title: string;
  description?: string;
  content?: any;
  isActive: boolean;
  order: number;
}

export interface ProductWithOrders extends Product {
  orderItems: OrderItem[];
  _count: {
    orderItems: number;
  };
}

export interface OrderWithDetails extends Order {
  orderItems: OrderItem[];
  contact?: Contact;
  funnel: Funnel;
}

export interface OrderItem {
  id: string;
  quantity: number;
  price: number;
  product: Product;
}

export interface ContactWithOrders extends Contact {
  order?: Order;
}

export interface DashboardStats {
  totalOrders: number;
  totalRevenue: number;
  totalContacts: number;
  conversionRate: number;
  recentOrders: OrderWithDetails[];
  monthlyRevenue: Array<{
    month: string;
    revenue: number;
    orders: number;
  }>;
}

export interface CheckoutFormData {
  firstName: string;
  lastName: string;
  email: string;
  couponCode?: string;
}

export interface PageTemplate {
  id: string;
  name: string;
  description?: string;
  category: string;
  pageType: 'LANDING' | 'CHECKOUT' | 'THANK_YOU' | 'MEMBER_AREA';
  thumbnail?: string;
  content: any;
  isFree: boolean;
}
