
"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  User, 
  Globe, 
  CreditCard, 
  Bell, 
  Shield,
  Key,
  Mail,
  Smartphone,
  Save,
  Eye,
  EyeOff
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function SettingsManager() {
  const [showStripeKey, setShowStripeKey] = useState(false);
  const [settings, setSettings] = useState({
    profile: {
      firstName: 'Juan',
      lastName: 'Pérez',
      email: 'juan@example.com',
      phone: '+34 666 123 456',
      bio: 'Emprendedor digital especializado en marketing online',
      avatar: ''
    },
    business: {
      businessName: 'Mi Negocio Digital',
      website: 'https://minegocio.com',
      address: 'Madrid, España',
      taxId: 'B12345678',
      description: 'Creamos cursos digitales de alta calidad para emprendedores'
    },
    funnel: {
      defaultDomain: 'mi-embudo',
      customDomain: '',
      googleAnalytics: '',
      facebookPixel: '',
      customCss: '',
      footerText: '© 2024 Mi Negocio Digital. Todos los derechos reservados.'
    },
    payments: {
      stripePublishableKey: 'pk_test_...',
      stripeSecretKey: '••••••••••••••••••••',
      paypalClientId: '',
      currency: 'EUR',
      taxRate: '21'
    },
    notifications: {
      emailNewLead: true,
      emailNewSale: true,
      emailWeeklyReport: false,
      smsNewSale: false,
      pushNotifications: true
    },
    security: {
      twoFactorEnabled: false,
      sessionTimeout: '24',
      passwordLastChanged: '2024-01-15'
    }
  });

  const { toast } = useToast();

  const handleSave = async (section: string) => {
    try {
      const response = await fetch('/api/settings', {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          section,
          data: settings[section as keyof typeof settings],
        }),
      });

      if (!response.ok) throw new Error('Error al guardar la configuración');

      toast({
        title: "Configuración guardada",
        description: "Los cambios se han guardado correctamente",
      });

    } catch (error) {
      toast({
        title: "Error",
        description: "No se pudo guardar la configuración",
        variant: "destructive",
      });
    }
  };

  const updateSetting = (section: string, field: string, value: any) => {
    setSettings(prev => ({
      ...prev,
      [section]: {
        ...prev[section as keyof typeof prev],
        [field]: value
      }
    }));
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-2xl font-bold text-gray-900">Configuración</h2>
        <p className="text-gray-600">Administra la configuración de tu cuenta y embudo</p>
      </div>

      <Tabs defaultValue="profile" className="w-full">
        <TabsList className="grid grid-cols-2 lg:grid-cols-6 w-full">
          <TabsTrigger value="profile" className="flex items-center gap-2">
            <User className="w-4 h-4" />
            <span className="hidden sm:inline">Perfil</span>
          </TabsTrigger>
          <TabsTrigger value="business" className="flex items-center gap-2">
            <Globe className="w-4 h-4" />
            <span className="hidden sm:inline">Negocio</span>
          </TabsTrigger>
          <TabsTrigger value="funnel" className="flex items-center gap-2">
            <Globe className="w-4 h-4" />
            <span className="hidden sm:inline">Embudo</span>
          </TabsTrigger>
          <TabsTrigger value="payments" className="flex items-center gap-2">
            <CreditCard className="w-4 h-4" />
            <span className="hidden sm:inline">Pagos</span>
          </TabsTrigger>
          <TabsTrigger value="notifications" className="flex items-center gap-2">
            <Bell className="w-4 h-4" />
            <span className="hidden sm:inline">Notificaciones</span>
          </TabsTrigger>
          <TabsTrigger value="security" className="flex items-center gap-2">
            <Shield className="w-4 h-4" />
            <span className="hidden sm:inline">Seguridad</span>
          </TabsTrigger>
        </TabsList>

        {/* Profile Settings */}
        <TabsContent value="profile" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Información Personal</CardTitle>
              <CardDescription>
                Actualiza tu información de perfil
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="firstName">Nombre</Label>
                  <Input
                    id="firstName"
                    value={settings.profile.firstName}
                    onChange={(e) => updateSetting('profile', 'firstName', e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="lastName">Apellidos</Label>
                  <Input
                    id="lastName"
                    value={settings.profile.lastName}
                    onChange={(e) => updateSetting('profile', 'lastName', e.target.value)}
                  />
                </div>
              </div>
              
              <div>
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  value={settings.profile.email}
                  onChange={(e) => updateSetting('profile', 'email', e.target.value)}
                />
              </div>
              
              <div>
                <Label htmlFor="phone">Teléfono</Label>
                <Input
                  id="phone"
                  value={settings.profile.phone}
                  onChange={(e) => updateSetting('profile', 'phone', e.target.value)}
                />
              </div>
              
              <div>
                <Label htmlFor="bio">Biografía</Label>
                <Textarea
                  id="bio"
                  value={settings.profile.bio}
                  onChange={(e) => updateSetting('profile', 'bio', e.target.value)}
                  rows={3}
                />
              </div>
              
              <Button onClick={() => handleSave('profile')} className="bg-blue-600 hover:bg-blue-700">
                <Save className="w-4 h-4 mr-2" />
                Guardar Perfil
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Business Settings */}
        <TabsContent value="business" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Información del Negocio</CardTitle>
              <CardDescription>
                Configura los detalles de tu empresa
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="businessName">Nombre del Negocio</Label>
                <Input
                  id="businessName"
                  value={settings.business.businessName}
                  onChange={(e) => updateSetting('business', 'businessName', e.target.value)}
                />
              </div>
              
              <div>
                <Label htmlFor="website">Sitio Web</Label>
                <Input
                  id="website"
                  value={settings.business.website}
                  onChange={(e) => updateSetting('business', 'website', e.target.value)}
                />
              </div>
              
              <div>
                <Label htmlFor="address">Dirección</Label>
                <Input
                  id="address"
                  value={settings.business.address}
                  onChange={(e) => updateSetting('business', 'address', e.target.value)}
                />
              </div>
              
              <div>
                <Label htmlFor="taxId">NIF/CIF</Label>
                <Input
                  id="taxId"
                  value={settings.business.taxId}
                  onChange={(e) => updateSetting('business', 'taxId', e.target.value)}
                />
              </div>
              
              <div>
                <Label htmlFor="description">Descripción del Negocio</Label>
                <Textarea
                  id="description"
                  value={settings.business.description}
                  onChange={(e) => updateSetting('business', 'description', e.target.value)}
                  rows={3}
                />
              </div>
              
              <Button onClick={() => handleSave('business')} className="bg-blue-600 hover:bg-blue-700">
                <Save className="w-4 h-4 mr-2" />
                Guardar Información
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Funnel Settings */}
        <TabsContent value="funnel" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Configuración del Embudo</CardTitle>
              <CardDescription>
                Personaliza tu embudo de ventas
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="defaultDomain">Subdominio por Defecto</Label>
                <div className="flex">
                  <Input
                    id="defaultDomain"
                    value={settings.funnel.defaultDomain}
                    onChange={(e) => updateSetting('funnel', 'defaultDomain', e.target.value)}
                    className="rounded-r-none"
                  />
                  <div className="bg-gray-100 border border-l-0 rounded-r-md px-3 py-2 text-sm text-gray-600">
                    .embudos.app
                  </div>
                </div>
              </div>
              
              <div>
                <Label htmlFor="customDomain">Dominio Personalizado (Opcional)</Label>
                <Input
                  id="customDomain"
                  placeholder="tu-dominio.com"
                  value={settings.funnel.customDomain}
                  onChange={(e) => updateSetting('funnel', 'customDomain', e.target.value)}
                />
              </div>
              
              <div>
                <Label htmlFor="googleAnalytics">Google Analytics ID</Label>
                <Input
                  id="googleAnalytics"
                  placeholder="G-XXXXXXXXXX"
                  value={settings.funnel.googleAnalytics}
                  onChange={(e) => updateSetting('funnel', 'googleAnalytics', e.target.value)}
                />
              </div>
              
              <div>
                <Label htmlFor="facebookPixel">Facebook Pixel ID</Label>
                <Input
                  id="facebookPixel"
                  placeholder="123456789"
                  value={settings.funnel.facebookPixel}
                  onChange={(e) => updateSetting('funnel', 'facebookPixel', e.target.value)}
                />
              </div>
              
              <div>
                <Label htmlFor="customCss">CSS Personalizado</Label>
                <Textarea
                  id="customCss"
                  placeholder="/* Tu CSS personalizado aquí */"
                  value={settings.funnel.customCss}
                  onChange={(e) => updateSetting('funnel', 'customCss', e.target.value)}
                  rows={4}
                />
              </div>
              
              <div>
                <Label htmlFor="footerText">Texto del Footer</Label>
                <Input
                  id="footerText"
                  value={settings.funnel.footerText}
                  onChange={(e) => updateSetting('funnel', 'footerText', e.target.value)}
                />
              </div>
              
              <Button onClick={() => handleSave('funnel')} className="bg-blue-600 hover:bg-blue-700">
                <Save className="w-4 h-4 mr-2" />
                Guardar Configuración
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Payments Settings */}
        <TabsContent value="payments" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Configuración de Pagos</CardTitle>
              <CardDescription>
                Configura tus métodos de pago
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="stripePublishable">Stripe Publishable Key</Label>
                <Input
                  id="stripePublishable"
                  value={settings.payments.stripePublishableKey}
                  onChange={(e) => updateSetting('payments', 'stripePublishableKey', e.target.value)}
                />
              </div>
              
              <div>
                <Label htmlFor="stripeSecret">Stripe Secret Key</Label>
                <div className="flex">
                  <Input
                    id="stripeSecret"
                    type={showStripeKey ? "text" : "password"}
                    value={settings.payments.stripeSecretKey}
                    onChange={(e) => updateSetting('payments', 'stripeSecretKey', e.target.value)}
                    className="rounded-r-none"
                  />
                  <Button
                    type="button"
                    variant="outline"
                    className="rounded-l-none"
                    onClick={() => setShowStripeKey(!showStripeKey)}
                  >
                    {showStripeKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </Button>
                </div>
              </div>
              
              <div>
                <Label htmlFor="paypalClientId">PayPal Client ID</Label>
                <Input
                  id="paypalClientId"
                  placeholder="Próximamente disponible"
                  value={settings.payments.paypalClientId}
                  onChange={(e) => updateSetting('payments', 'paypalClientId', e.target.value)}
                  disabled
                />
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="currency">Moneda</Label>
                  <select
                    id="currency"
                    value={settings.payments.currency}
                    onChange={(e) => updateSetting('payments', 'currency', e.target.value)}
                    className="w-full p-2 border rounded-md"
                  >
                    <option value="EUR">EUR (€)</option>
                    <option value="USD">USD ($)</option>
                    <option value="GBP">GBP (£)</option>
                  </select>
                </div>
                <div>
                  <Label htmlFor="taxRate">Tasa de IVA (%)</Label>
                  <Input
                    id="taxRate"
                    type="number"
                    min="0"
                    max="100"
                    step="0.1"
                    value={settings.payments.taxRate}
                    onChange={(e) => updateSetting('payments', 'taxRate', e.target.value)}
                  />
                </div>
              </div>
              
              <Button onClick={() => handleSave('payments')} className="bg-blue-600 hover:bg-blue-700">
                <Save className="w-4 h-4 mr-2" />
                Guardar Configuración
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Notifications Settings */}
        <TabsContent value="notifications" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Configuración de Notificaciones</CardTitle>
              <CardDescription>
                Elige cómo quieres recibir notificaciones
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <h3 className="font-medium flex items-center gap-2">
                  <Mail className="w-4 h-4" />
                  Notificaciones por Email
                </h3>
                
                <div className="space-y-3 ml-6">
                  <label className="flex items-center gap-2">
                    <input
                      type="checkbox"
                      checked={settings.notifications.emailNewLead}
                      onChange={(e) => updateSetting('notifications', 'emailNewLead', e.target.checked)}
                    />
                    <span>Nuevo lead registrado</span>
                  </label>
                  
                  <label className="flex items-center gap-2">
                    <input
                      type="checkbox"
                      checked={settings.notifications.emailNewSale}
                      onChange={(e) => updateSetting('notifications', 'emailNewSale', e.target.checked)}
                    />
                    <span>Nueva venta realizada</span>
                  </label>
                  
                  <label className="flex items-center gap-2">
                    <input
                      type="checkbox"
                      checked={settings.notifications.emailWeeklyReport}
                      onChange={(e) => updateSetting('notifications', 'emailWeeklyReport', e.target.checked)}
                    />
                    <span>Reporte semanal de estadísticas</span>
                  </label>
                </div>
              </div>

              <div className="space-y-4">
                <h3 className="font-medium flex items-center gap-2">
                  <Smartphone className="w-4 h-4" />
                  Notificaciones SMS
                </h3>
                
                <div className="space-y-3 ml-6">
                  <label className="flex items-center gap-2">
                    <input
                      type="checkbox"
                      checked={settings.notifications.smsNewSale}
                      onChange={(e) => updateSetting('notifications', 'smsNewSale', e.target.checked)}
                    />
                    <span>Nueva venta realizada</span>
                  </label>
                </div>
              </div>

              <div className="space-y-4">
                <h3 className="font-medium flex items-center gap-2">
                  <Bell className="w-4 h-4" />
                  Notificaciones Push
                </h3>
                
                <div className="space-y-3 ml-6">
                  <label className="flex items-center gap-2">
                    <input
                      type="checkbox"
                      checked={settings.notifications.pushNotifications}
                      onChange={(e) => updateSetting('notifications', 'pushNotifications', e.target.checked)}
                    />
                    <span>Notificaciones del navegador</span>
                  </label>
                </div>
              </div>
              
              <Button onClick={() => handleSave('notifications')} className="bg-blue-600 hover:bg-blue-700">
                <Save className="w-4 h-4 mr-2" />
                Guardar Preferencias
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Security Settings */}
        <TabsContent value="security" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Configuración de Seguridad</CardTitle>
              <CardDescription>
                Protege tu cuenta con configuraciones de seguridad
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between p-4 border rounded-lg">
                <div>
                  <h4 className="font-medium">Autenticación de Dos Factores</h4>
                  <p className="text-sm text-gray-600">
                    Añade una capa extra de seguridad a tu cuenta
                  </p>
                </div>
                <Button
                  variant={settings.security.twoFactorEnabled ? "destructive" : "default"}
                  onClick={() => updateSetting('security', 'twoFactorEnabled', !settings.security.twoFactorEnabled)}
                >
                  {settings.security.twoFactorEnabled ? 'Desactivar' : 'Activar'}
                </Button>
              </div>

              <div>
                <Label htmlFor="sessionTimeout">Tiempo de sesión (horas)</Label>
                <select
                  id="sessionTimeout"
                  value={settings.security.sessionTimeout}
                  onChange={(e) => updateSetting('security', 'sessionTimeout', e.target.value)}
                  className="w-full p-2 border rounded-md"
                >
                  <option value="1">1 hora</option>
                  <option value="8">8 horas</option>
                  <option value="24">24 horas</option>
                  <option value="168">1 semana</option>
                </select>
              </div>

              <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                <h4 className="font-medium text-yellow-800">Cambio de Contraseña</h4>
                <p className="text-sm text-yellow-700 mb-3">
                  Última actualización: {settings.security.passwordLastChanged}
                </p>
                <Button variant="outline" size="sm">
                  <Key className="w-4 h-4 mr-2" />
                  Cambiar Contraseña
                </Button>
              </div>
              
              <Button onClick={() => handleSave('security')} className="bg-blue-600 hover:bg-blue-700">
                <Save className="w-4 h-4 mr-2" />
                Guardar Configuración
              </Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
