
"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { signOut } from "next-auth/react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { 
  BarChart, 
  Users, 
  TrendingUp, 
  DollarSign, 
  Settings, 
  Plus,
  Eye,
  Edit,
  Zap,
  LogOut,
  Package,
  Mail,
  Globe
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import FunnelBuilder from "@/components/funnel/funnel-builder";
import FunnelPreview from "@/components/funnel/funnel-preview";
import ProductManager from "@/components/products/product-manager";
import ContactManager from "@/components/contacts/contact-manager";
import SettingsManager from "@/components/settings/settings-manager";

interface DashboardMainProps {
  funnel: any;
  stats: any;
  user: any;
}

export default function DashboardMain({ funnel, stats, user }: DashboardMainProps) {
  const [activeTab, setActiveTab] = useState("overview");
  const [showPreview, setShowPreview] = useState(false);
  const [funnelData, setFunnelData] = useState(funnel);

  const menuItems = [
    { id: "overview", label: "Resumen", icon: BarChart },
    { id: "funnel", label: "Mi Embudo", icon: TrendingUp },
    { id: "products", label: "Productos", icon: Package },
    { id: "contacts", label: "Contactos", icon: Users },
    { id: "settings", label: "Configuración", icon: Settings },
  ];

  const handleLogout = () => {
    signOut({ callbackUrl: "/" });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50">
      {/* Header */}
      <header className="sticky top-0 z-50 backdrop-blur-md bg-white/80 border-b border-white/20">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 bg-gradient-to-br from-blue-600 to-purple-600 rounded-lg flex items-center justify-center">
              <Zap className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-gray-800">Embudos Digitales</h1>
              <p className="text-sm text-gray-600">Bienvenido, {user?.firstName}</p>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
              {funnelData?.isPublished ? "Publicado" : "Borrador"}
            </Badge>
            <Button
              variant="outline"
              size="sm"
              onClick={handleLogout}
              className="text-gray-600 hover:text-gray-800"
            >
              <LogOut className="w-4 h-4 mr-2" />
              Salir
            </Button>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto p-4">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Sidebar */}
          <div className="lg:col-span-1">
            <Card className="bg-white/70 backdrop-blur-sm border-0 shadow-lg">
              <CardHeader className="pb-4">
                <CardTitle className="text-lg">Panel de Control</CardTitle>
                <CardDescription>
                  Gestiona tu embudo de ventas
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-2">
                {menuItems.map((item) => (
                  <Button
                    key={item.id}
                    variant={activeTab === item.id ? "default" : "ghost"}
                    className={`w-full justify-start ${
                      activeTab === item.id
                        ? "bg-gradient-to-r from-blue-600 to-purple-600"
                        : "hover:bg-white/50"
                    }`}
                    onClick={() => setActiveTab(item.id)}
                  >
                    <item.icon className="w-4 h-4 mr-2" />
                    {item.label}
                  </Button>
                ))}
              </CardContent>
            </Card>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-3">
            {activeTab === "overview" && (
              <div className="space-y-6">
                {/* Stats Cards */}
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                  <StatsCard
                    title="Ventas Totales"
                    value={`€${stats?.totalRevenue?.toFixed(2) || "0.00"}`}
                    icon={DollarSign}
                    gradient="from-green-500 to-emerald-600"
                  />
                  <StatsCard
                    title="Pedidos"
                    value={stats?.totalOrders || 0}
                    icon={Package}
                    gradient="from-blue-500 to-indigo-600"
                  />
                  <StatsCard
                    title="Contactos"
                    value={stats?.totalContacts || 0}
                    icon={Users}
                    gradient="from-purple-500 to-violet-600"
                  />
                  <StatsCard
                    title="Conversión"
                    value={`${stats?.conversionRate?.toFixed(1) || "0.0"}%`}
                    icon={TrendingUp}
                    gradient="from-orange-500 to-red-600"
                  />
                </div>

                {/* Quick Actions */}
                <Card className="bg-white/70 backdrop-blur-sm border-0 shadow-lg">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Zap className="w-5 h-5 text-blue-600" />
                      Acciones Rápidas
                    </CardTitle>
                    <CardDescription>
                      Administra tu embudo de forma eficiente
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <Button
                        className="h-20 flex flex-col items-center justify-center gap-2 bg-gradient-to-br from-blue-50 to-indigo-50 text-blue-700 border-blue-200 hover:bg-blue-100"
                        variant="outline"
                        onClick={() => setActiveTab("funnel")}
                      >
                        <Edit className="w-6 h-6" />
                        <span>Editar Embudo</span>
                      </Button>

                      <Button
                        className="h-20 flex flex-col items-center justify-center gap-2 bg-gradient-to-br from-green-50 to-emerald-50 text-green-700 border-green-200 hover:bg-green-100"
                        variant="outline"
                        onClick={() => setActiveTab("products")}
                      >
                        <Plus className="w-6 h-6" />
                        <span>Añadir Producto</span>
                      </Button>

                      <Button
                        className="h-20 flex flex-col items-center justify-center gap-2 bg-gradient-to-br from-purple-50 to-violet-50 text-purple-700 border-purple-200 hover:bg-purple-100"
                        variant="outline"
                        onClick={() => {
                          setActiveTab("funnel");
                          setShowPreview(true);
                        }}
                      >
                        <Eye className="w-6 h-6" />
                        <span>Vista Previa</span>
                      </Button>
                    </div>
                  </CardContent>
                </Card>

                {/* Funnel Status */}
                <Card className="bg-white/70 backdrop-blur-sm border-0 shadow-lg">
                  <CardHeader>
                    <CardTitle>Estado del Embudo</CardTitle>
                    <CardDescription>
                      {funnel?.name || "Mi Embudo Digital"}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="flex items-center justify-between p-4 bg-blue-50 rounded-lg">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center">
                            <Globe className="w-5 h-5 text-white" />
                          </div>
                          <div>
                            <h4 className="font-semibold text-gray-800">Configuración Básica</h4>
                            <p className="text-sm text-gray-600">Nombre, descripción y configuración inicial</p>
                          </div>
                        </div>
                        <Badge className="bg-green-100 text-green-800">
                          {funnelData?.name ? "Completado" : "Pendiente"}
                        </Badge>
                      </div>

                      <div className="flex items-center justify-between p-4 bg-yellow-50 rounded-lg">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 bg-yellow-600 rounded-lg flex items-center justify-center">
                            <Package className="w-5 h-5 text-white" />
                          </div>
                          <div>
                            <h4 className="font-semibold text-gray-800">Productos</h4>
                            <p className="text-sm text-gray-600">
                              {funnelData?.steps?.checkout?.productName ? "1 producto configurado" : "0 productos configurados"}
                            </p>
                          </div>
                        </div>
                        <Badge variant="outline" className="border-yellow-300 text-yellow-800">
                          {funnelData?.steps?.checkout?.productName ? "Configurado" : "Pendiente"}
                        </Badge>
                      </div>

                      <div className="flex items-center justify-between p-4 bg-purple-50 rounded-lg">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 bg-purple-600 rounded-lg flex items-center justify-center">
                            <Eye className="w-5 h-5 text-white" />
                          </div>
                          <div>
                            <h4 className="font-semibold text-gray-800">Publicación</h4>
                            <p className="text-sm text-gray-600">
                              {funnelData?.isPublished ? "Embudo activo y visible" : "Embudo en borrador"}
                            </p>
                          </div>
                        </div>
                        <Badge variant={funnelData?.isPublished ? "default" : "outline"}>
                          {funnelData?.isPublished ? "Publicado" : "Borrador"}
                        </Badge>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            )}

            {activeTab === "funnel" && !showPreview && (
              <FunnelBuilder 
                funnel={funnelData}
                onUpdateFunnel={(updatedFunnel) => setFunnelData(updatedFunnel)}
              />
            )}
            
            {activeTab === "funnel" && showPreview && (
              <FunnelPreview 
                funnelData={funnelData}
                onBack={() => setShowPreview(false)}
              />
            )}

            {activeTab === "products" && (
              <ProductManager />
            )}

            {activeTab === "contacts" && (
              <ContactManager />
            )}

            {activeTab === "settings" && (
              <SettingsManager />
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

function StatsCard({ title, value, icon: Icon, gradient }: any) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={{ scale: 1.02 }}
      className="group cursor-pointer"
    >
      <Card className="bg-white/70 backdrop-blur-sm border-0 shadow-lg hover:shadow-xl transition-all">
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">{title}</p>
              <p className="text-2xl font-bold text-gray-900">{value}</p>
            </div>
            <div className={`w-12 h-12 rounded-lg bg-gradient-to-br ${gradient} flex items-center justify-center group-hover:scale-110 transition-transform`}>
              <Icon className="w-6 h-6 text-white" />
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}
