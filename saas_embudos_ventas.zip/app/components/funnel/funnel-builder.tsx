
"use client";

import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  ArrowRight, 
  Settings, 
  Eye, 
  Save, 
  Globe, 
  CreditCard,
  Gift,
  CheckCircle,
  Edit,
  Palette,
  Type,
  Image as ImageIcon
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface FunnelBuilderProps {
  funnel: any;
  onUpdateFunnel: (updatedFunnel: any) => void;
}

interface FunnelStep {
  id: string;
  name: string;
  type: "landing" | "checkout" | "thanks";
  icon: any;
  color: string;
  description: string;
}

const FUNNEL_STEPS: FunnelStep[] = [
  {
    id: "landing",
    name: "Landing Page",
    type: "landing",
    icon: Globe,
    color: "from-blue-500 to-indigo-600",
    description: "Página principal para atraer visitantes"
  },
  {
    id: "checkout",
    name: "Checkout",
    type: "checkout", 
    icon: CreditCard,
    color: "from-green-500 to-emerald-600",
    description: "Página de pago para procesar ventas"
  },
  {
    id: "thanks",
    name: "Página de Gracias",
    type: "thanks",
    icon: Gift,
    color: "from-purple-500 to-violet-600", 
    description: "Página de confirmación y descarga"
  }
];

export default function FunnelBuilder({ funnel, onUpdateFunnel }: FunnelBuilderProps) {
  const [activeStep, setActiveStep] = useState<string>("landing");
  
  // Datos por defecto del embudo
  const defaultFunnelData = {
    name: "Mi Embudo Digital",
    subdomain: "",
    isPublished: false,
    steps: {
      landing: {
        title: "¡Transforma Tu Negocio Digital!",
        subtitle: "Descubre el secreto para generar ingresos online de forma automatizada",
        description: "Aprende las estrategias que usan los expertos para crear embudos de ventas que convierten visitantes en clientes fieles.",
        ctaText: "¡Quiero Acceso Ahora!",
        benefits: [
          "Acceso inmediato al contenido",
          "Estrategias probadas y efectivas", 
          "Soporte completo incluido"
        ],
        backgroundColor: "#ffffff",
        textColor: "#1f2937",
        buttonColor: "#3b82f6"
      },
      checkout: {
        productName: "Curso Digital Premium",
        price: 25.00,
        currency: "EUR",
        description: "Acceso completo al curso con todos los materiales y bonuses incluidos.",
        features: [
          "Más de 50 lecciones en video",
          "Plantillas y recursos descargables",
          "Acceso de por vida",
          "Garantía de 30 días"
        ],
        paymentMethods: ["stripe"],
        discountCodes: []
      },
      thanks: {
        title: "¡Felicidades por Tu Compra!",
        message: "Gracias por confiar en nosotros. Tu producto digital está listo para descarga.",
        downloadInstructions: "Recibirás un email con el enlace de descarga en los próximos minutos. También puedes acceder desde tu área de miembros.",
        socialShare: true,
        additionalOffers: []
      }
    }
  };

  const [funnelData, setFunnelData] = useState(() => {
    // Si no hay datos del embudo, usar los datos por defecto
    if (!funnel) return defaultFunnelData;
    
    // Fusionar datos existentes con datos por defecto para evitar undefined
    return {
      ...defaultFunnelData,
      ...funnel,
      steps: {
        landing: {
          ...defaultFunnelData.steps.landing,
          ...(funnel.steps?.landing || {})
        },
        checkout: {
          ...defaultFunnelData.steps.checkout,
          ...(funnel.steps?.checkout || {})
        },
        thanks: {
          ...defaultFunnelData.steps.thanks,
          ...(funnel.steps?.thanks || {})
        }
      }
    };
  });

  const { toast } = useToast();

  const handleStepUpdate = (stepType: string, updates: any) => {
    setFunnelData((prev: any) => ({
      ...prev,
      steps: {
        ...prev.steps,
        [stepType]: {
          ...prev.steps[stepType],
          ...updates
        }
      }
    }));
  };

  const handleSaveFunnel = async () => {
    try {
      // Aquí iría la lógica para guardar en la base de datos
      onUpdateFunnel(funnelData);
      toast({
        title: "Embudo guardado",
        description: "Los cambios se han guardado correctamente.",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "No se pudo guardar el embudo. Inténtalo de nuevo.",
        variant: "destructive",
      });
    }
  };

  const handlePublishFunnel = async () => {
    if (!funnelData.subdomain) {
      toast({
        title: "Subdominio requerido",
        description: "Debes configurar un subdominio antes de publicar.",
        variant: "destructive",
      });
      return;
    }

    try {
      const updatedFunnel = { ...funnelData, isPublished: !funnelData.isPublished };
      setFunnelData(updatedFunnel);
      onUpdateFunnel(updatedFunnel);
      
      toast({
        title: funnelData.isPublished ? "Embudo despublicado" : "¡Embudo publicado!",
        description: funnelData.isPublished 
          ? "El embudo ya no está disponible públicamente." 
          : "Tu embudo ya está disponible en tu subdominio.",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "No se pudo cambiar el estado de publicación.",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Mi Embudo</h2>
          <p className="text-gray-600">Configura y personaliza tu embudo de ventas</p>
        </div>
        <div className="flex items-center gap-3">
          <Badge variant={funnelData.isPublished ? "default" : "outline"}>
            {funnelData.isPublished ? "Publicado" : "Borrador"}
          </Badge>
          <Button variant="outline" onClick={handleSaveFunnel}>
            <Save className="w-4 h-4 mr-2" />
            Guardar
          </Button>
          <Button 
            onClick={handlePublishFunnel}
            className={funnelData.isPublished ? "bg-red-600 hover:bg-red-700" : ""}
          >
            <Globe className="w-4 h-4 mr-2" />
            {funnelData.isPublished ? "Despublicar" : "Publicar"}
          </Button>
        </div>
      </div>

      {/* Funnel Overview */}
      <Card className="bg-white/70 backdrop-blur-sm border-0 shadow-lg">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Settings className="w-5 h-5 text-blue-600" />
            Configuración General
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="funnelName">Nombre del Embudo</Label>
              <Input
                id="funnelName"
                value={funnelData.name}
                onChange={(e) => setFunnelData((prev: any) => ({ ...prev, name: e.target.value }))}
                placeholder="Mi Embudo Digital"
              />
            </div>
            <div>
              <Label htmlFor="subdomain">Subdominio</Label>
              <div className="flex">
                <Input
                  id="subdomain"
                  value={funnelData.subdomain}
                  onChange={(e) => setFunnelData((prev: any) => ({ ...prev, subdomain: e.target.value }))}
                  placeholder="mi-embudo"
                  className="rounded-r-none"
                />
                <div className="bg-gray-100 border border-l-0 rounded-r-md px-3 py-2 text-sm text-gray-600">
                  .embudos.app
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Funnel Steps Visual */}
      <Card className="bg-white/70 backdrop-blur-sm border-0 shadow-lg">
        <CardHeader>
          <CardTitle>Flujo del Embudo</CardTitle>
          <CardDescription>Haz clic en cualquier paso para editarlo</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between">
            {FUNNEL_STEPS.map((step, index) => (
              <div key={step.id} className="flex items-center">
                <motion.div
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => setActiveStep(step.id)}
                  className={`relative cursor-pointer p-4 rounded-xl border-2 transition-all ${
                    activeStep === step.id 
                      ? "border-blue-500 bg-blue-50 shadow-lg" 
                      : "border-gray-200 bg-white hover:border-gray-300"
                  }`}
                >
                  <div className={`w-12 h-12 rounded-lg bg-gradient-to-br ${step.color} flex items-center justify-center mb-3`}>
                    <step.icon className="w-6 h-6 text-white" />
                  </div>
                  <h3 className="font-semibold text-sm text-gray-900">{step.name}</h3>
                  <p className="text-xs text-gray-600 mt-1">{step.description}</p>
                  
                  {/* Step Status */}
                  <div className="absolute -top-2 -right-2">
                    <div className="w-6 h-6 bg-green-500 rounded-full flex items-center justify-center">
                      <CheckCircle className="w-4 h-4 text-white" />
                    </div>
                  </div>
                </motion.div>
                
                {index < FUNNEL_STEPS.length - 1 && (
                  <ArrowRight className="w-6 h-6 text-gray-400 mx-4" />
                )}
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Step Editor */}
      <AnimatePresence mode="wait">
        <motion.div
          key={activeStep}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -20 }}
          transition={{ duration: 0.2 }}
        >
          {activeStep === "landing" && (
            <LandingPageEditor 
              data={funnelData?.steps?.landing || {}} 
              onUpdate={(updates: any) => handleStepUpdate("landing", updates)}
            />
          )}
          
          {activeStep === "checkout" && (
            <CheckoutPageEditor 
              data={funnelData?.steps?.checkout || {}} 
              onUpdate={(updates: any) => handleStepUpdate("checkout", updates)}
            />
          )}
          
          {activeStep === "thanks" && (
            <ThanksPageEditor 
              data={funnelData?.steps?.thanks || {}} 
              onUpdate={(updates: any) => handleStepUpdate("thanks", updates)}
            />
          )}
        </motion.div>
      </AnimatePresence>

      {/* Preview Section */}
      {funnelData.subdomain && (
        <Card className="bg-gradient-to-r from-blue-50 to-indigo-50 border-blue-200">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-blue-800">
              <Eye className="w-5 h-5" />
              Vista Previa del Embudo
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div>
                <p className="text-blue-700 font-medium">
                  {funnelData.subdomain}.embudos.app
                </p>
                <p className="text-blue-600 text-sm">
                  {funnelData.isPublished ? "Activo y recibiendo visitantes" : "En desarrollo"}
                </p>
              </div>
              <Button 
                variant="outline" 
                className="border-blue-300 text-blue-700 hover:bg-blue-100"
                disabled={!funnelData.isPublished}
              >
                <Eye className="w-4 h-4 mr-2" />
                Ver Embudo
              </Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

// Landing Page Editor Component
function LandingPageEditor({ data, onUpdate }: any) {
  return (
    <Card className="bg-white/70 backdrop-blur-sm border-0 shadow-lg">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Globe className="w-5 h-5 text-blue-600" />
          Editar Landing Page
        </CardTitle>
        <CardDescription>
          Personaliza la página principal de tu embudo
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="content" className="w-full">
          <TabsList className="grid grid-cols-2 w-full max-w-md">
            <TabsTrigger value="content">Contenido</TabsTrigger>
            <TabsTrigger value="design">Diseño</TabsTrigger>
          </TabsList>
          
          <TabsContent value="content" className="space-y-6 mt-6">
            <div>
              <Label htmlFor="title">Título Principal</Label>
              <Input
                id="title"
                value={data.title}
                onChange={(e) => onUpdate({ title: e.target.value })}
                placeholder="Tu título principal aquí"
              />
            </div>
            
            <div>
              <Label htmlFor="subtitle">Subtítulo</Label>
              <Input
                id="subtitle"
                value={data.subtitle}
                onChange={(e) => onUpdate({ subtitle: e.target.value })}
                placeholder="Subtítulo descriptivo"
              />
            </div>
            
            <div>
              <Label htmlFor="description">Descripción</Label>
              <Textarea
                id="description"
                value={data.description}
                onChange={(e) => onUpdate({ description: e.target.value })}
                placeholder="Describe tu oferta..."
                rows={4}
              />
            </div>
            
            <div>
              <Label htmlFor="ctaText">Texto del Botón</Label>
              <Input
                id="ctaText"
                value={data.ctaText}
                onChange={(e) => onUpdate({ ctaText: e.target.value })}
                placeholder="¡Comprar Ahora!"
              />
            </div>

            <div>
              <Label>Beneficios Principales</Label>
              <div className="space-y-2 mt-2">
                {data?.benefits?.map((benefit: string, index: number) => (
                  <div key={index} className="flex items-center gap-2">
                    <Input
                      value={benefit}
                      onChange={(e) => {
                        const newBenefits = [...(data?.benefits || [])];
                        newBenefits[index] = e.target.value;
                        onUpdate({ benefits: newBenefits });
                      }}
                      placeholder="Beneficio"
                    />
                  </div>
                ))}
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    const newBenefits = [...(data?.benefits || []), ""];
                    onUpdate({ benefits: newBenefits });
                  }}
                >
                  Añadir Beneficio
                </Button>
              </div>
            </div>
          </TabsContent>
          
          <TabsContent value="design" className="space-y-6 mt-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <Label htmlFor="backgroundColor">Color de Fondo</Label>
                <Input
                  id="backgroundColor"
                  type="color"
                  value={data.backgroundColor}
                  onChange={(e) => onUpdate({ backgroundColor: e.target.value })}
                />
              </div>
              
              <div>
                <Label htmlFor="textColor">Color del Texto</Label>
                <Input
                  id="textColor"
                  type="color"
                  value={data.textColor}
                  onChange={(e) => onUpdate({ textColor: e.target.value })}
                />
              </div>
              
              <div>
                <Label htmlFor="buttonColor">Color del Botón</Label>
                <Input
                  id="buttonColor"
                  type="color"
                  value={data.buttonColor}
                  onChange={(e) => onUpdate({ buttonColor: e.target.value })}
                />
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}

// Checkout Page Editor Component
function CheckoutPageEditor({ data, onUpdate }: any) {
  return (
    <Card className="bg-white/70 backdrop-blur-sm border-0 shadow-lg">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <CreditCard className="w-5 h-5 text-green-600" />
          Editar Página de Checkout
        </CardTitle>
        <CardDescription>
          Configura tu producto y opciones de pago
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="product" className="w-full">
          <TabsList className="grid grid-cols-2 w-full max-w-md">
            <TabsTrigger value="product">Producto</TabsTrigger>
            <TabsTrigger value="payment">Pagos</TabsTrigger>
          </TabsList>
          
          <TabsContent value="product" className="space-y-6 mt-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="productName">Nombre del Producto</Label>
                <Input
                  id="productName"
                  value={data.productName}
                  onChange={(e) => onUpdate({ productName: e.target.value })}
                  placeholder="Mi Producto Digital"
                />
              </div>
              
              <div>
                <Label htmlFor="price">Precio (€)</Label>
                <Input
                  id="price"
                  type="number"
                  step="0.01"
                  value={data.price}
                  onChange={(e) => onUpdate({ price: parseFloat(e.target.value) })}
                  placeholder="25.00"
                />
              </div>
            </div>
            
            <div>
              <Label htmlFor="description">Descripción del Producto</Label>
              <Textarea
                id="description"
                value={data.description}
                onChange={(e) => onUpdate({ description: e.target.value })}
                placeholder="Describe tu producto..."
                rows={3}
              />
            </div>

            <div>
              <Label>Características del Producto</Label>
              <div className="space-y-2 mt-2">
                {data?.features?.map((feature: string, index: number) => (
                  <div key={index} className="flex items-center gap-2">
                    <Input
                      value={feature}
                      onChange={(e) => {
                        const newFeatures = [...(data?.features || [])];
                        newFeatures[index] = e.target.value;
                        onUpdate({ features: newFeatures });
                      }}
                      placeholder="Característica"
                    />
                  </div>
                ))}
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    const newFeatures = [...(data?.features || []), ""];
                    onUpdate({ features: newFeatures });
                  }}
                >
                  Añadir Característica
                </Button>
              </div>
            </div>
          </TabsContent>
          
          <TabsContent value="payment" className="space-y-6 mt-6">
            <div>
              <Label>Métodos de Pago Aceptados</Label>
              <div className="flex items-center space-x-4 mt-2">
                <label className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    checked={data?.paymentMethods?.includes("stripe")}
                    onChange={(e) => {
                      const methods = data?.paymentMethods || [];
                      if (e.target.checked) {
                        onUpdate({ paymentMethods: [...methods, "stripe"] });
                      } else {
                        onUpdate({ paymentMethods: methods.filter((m: string) => m !== "stripe") });
                      }
                    }}
                    className="rounded"
                  />
                  <span>Stripe (Tarjetas)</span>
                </label>
              </div>
            </div>
            
            <div>
              <Label>Códigos de Descuento</Label>
              <p className="text-sm text-gray-600 mb-2">
                Próximamente podrás crear códigos de descuento personalizados
              </p>
              <Button variant="outline" disabled>
                Crear Código de Descuento
              </Button>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}

// Thanks Page Editor Component
function ThanksPageEditor({ data, onUpdate }: any) {
  return (
    <Card className="bg-white/70 backdrop-blur-sm border-0 shadow-lg">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Gift className="w-5 h-5 text-purple-600" />
          Editar Página de Gracias
        </CardTitle>
        <CardDescription>
          Configura la experiencia post-compra
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div>
          <Label htmlFor="thanksTitle">Título de Agradecimiento</Label>
          <Input
            id="thanksTitle"
            value={data.title}
            onChange={(e) => onUpdate({ title: e.target.value })}
            placeholder="¡Gracias por tu compra!"
          />
        </div>
        
        <div>
          <Label htmlFor="thanksMessage">Mensaje Principal</Label>
          <Textarea
            id="thanksMessage"
            value={data.message}
            onChange={(e) => onUpdate({ message: e.target.value })}
            placeholder="Mensaje de agradecimiento..."
            rows={3}
          />
        </div>
        
        <div>
          <Label htmlFor="downloadInstructions">Instrucciones de Descarga</Label>
          <Textarea
            id="downloadInstructions"
            value={data.downloadInstructions}
            onChange={(e) => onUpdate({ downloadInstructions: e.target.value })}
            placeholder="Instrucciones para acceder al producto..."
            rows={3}
          />
        </div>
        
        <div className="flex items-center space-x-2">
          <input
            type="checkbox"
            id="socialShare"
            checked={data.socialShare}
            onChange={(e) => onUpdate({ socialShare: e.target.checked })}
            className="rounded"
          />
          <Label htmlFor="socialShare">Mostrar botones de redes sociales</Label>
        </div>
      </CardContent>
    </Card>
  );
}
