
"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  ArrowLeft, 
  ArrowRight, 
  Smartphone, 
  Monitor, 
  Tablet,
  ExternalLink,
  Download,
  Check,
  Star,
  CreditCard,
  Shield,
  Gift
} from "lucide-react";

interface FunnelPreviewProps {
  funnelData: any;
  onBack: () => void;
}

export default function FunnelPreview({ funnelData, onBack }: FunnelPreviewProps) {
  const [currentStep, setCurrentStep] = useState(0);
  const [deviceView, setDeviceView] = useState<"desktop" | "tablet" | "mobile">("desktop");
  
  const steps = ["landing", "checkout", "thanks"];
  const stepNames = ["Landing Page", "Checkout", "Página de Gracias"];

  const getDeviceClass = () => {
    switch (deviceView) {
      case "mobile":
        return "w-80 h-[600px]";
      case "tablet": 
        return "w-[768px] h-[600px]";
      default:
        return "w-full h-[600px]";
    }
  };

  const renderLandingPage = () => {
    const { landing } = funnelData?.steps || {};
    
    return (
      <div 
        className="h-full flex flex-col justify-center items-center p-8 text-center"
        style={{ 
          backgroundColor: landing?.backgroundColor || "#ffffff",
          color: landing?.textColor || "#1f2937"
        }}
      >
        <div className="max-w-2xl space-y-6">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">
            {landing?.title || "¡Transforma Tu Negocio Digital!"}
          </h1>
          
          <h2 className="text-xl md:text-2xl opacity-90 mb-6">
            {landing?.subtitle || "Descubre el secreto para generar ingresos online"}
          </h2>
          
          <p className="text-lg opacity-80 mb-8">
            {landing?.description || "Aprende las estrategias que usan los expertos."}
          </p>
          
          {landing?.benefits && landing.benefits.length > 0 && (
            <div className="space-y-3 mb-8">
              {landing.benefits.map((benefit: string, index: number) => (
                <div key={index} className="flex items-center justify-center gap-3">
                  <Check className="w-5 h-5 text-green-500" />
                  <span>{benefit}</span>
                </div>
              ))}
            </div>
          )}
          
          <Button 
            size="lg" 
            className="text-white text-lg px-8 py-4"
            style={{ backgroundColor: landing?.buttonColor || "#3b82f6" }}
          >
            {landing?.ctaText || "¡Quiero Acceso Ahora!"}
          </Button>
        </div>
      </div>
    );
  };

  const renderCheckoutPage = () => {
    const { checkout } = funnelData?.steps || {};
    
    return (
      <div className="h-full bg-gray-50 flex items-center justify-center p-4">
        <div className="max-w-4xl w-full grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Product Info */}
          <Card className="p-6">
            <div className="space-y-6">
              <div>
                <h2 className="text-2xl font-bold text-gray-900 mb-2">
                  {checkout?.productName || "Curso Digital Premium"}
                </h2>
                <p className="text-gray-600">
                  {checkout?.description || "Acceso completo al curso con todos los materiales incluidos."}
                </p>
              </div>
              
              <div className="space-y-3">
                {checkout?.features?.map((feature: string, index: number) => (
                  <div key={index} className="flex items-center gap-3">
                    <Check className="w-5 h-5 text-green-500" />
                    <span className="text-gray-700">{feature}</span>
                  </div>
                ))}
              </div>
              
              <div className="flex items-center gap-2">
                {[1,2,3,4,5].map((star) => (
                  <Star key={star} className="w-5 h-5 text-yellow-400 fill-current" />
                ))}
                <span className="text-gray-600 ml-2">(127 reseñas)</span>
              </div>
            </div>
          </Card>
          
          {/* Payment Form */}
          <Card className="p-6">
            <div className="space-y-6">
              <div className="text-center">
                <div className="text-3xl font-bold text-gray-900">
                  €{(checkout?.price || 25.00).toFixed(2)}
                </div>
                <p className="text-gray-600">Pago único - Acceso de por vida</p>
              </div>
              
              <div className="space-y-4">
                <input
                  type="email"
                  placeholder="Email"
                  className="w-full p-3 border rounded-lg"
                />
                <input
                  type="text"
                  placeholder="Nombre completo"
                  className="w-full p-3 border rounded-lg"
                />
                <div className="bg-gray-100 p-4 rounded-lg">
                  <div className="flex items-center gap-2 mb-2">
                    <CreditCard className="w-5 h-5 text-gray-600" />
                    <span className="font-medium">Información de pago</span>
                  </div>
                  <p className="text-sm text-gray-600">
                    Pago seguro procesado por Stripe
                  </p>
                </div>
              </div>
              
              <Button className="w-full bg-green-600 hover:bg-green-700 text-white py-3">
                <Shield className="w-4 h-4 mr-2" />
                Proceder al Pago Seguro
              </Button>
              
              <div className="text-center text-sm text-gray-600">
                <Shield className="w-4 h-4 inline mr-1" />
                Garantía de devolución de 30 días
              </div>
            </div>
          </Card>
        </div>
      </div>
    );
  };

  const renderThanksPage = () => {
    const { thanks } = funnelData?.steps || {};
    
    return (
      <div className="h-full bg-gradient-to-br from-green-50 to-blue-50 flex items-center justify-center p-8">
        <div className="max-w-2xl text-center space-y-6">
          <div className="w-20 h-20 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-6">
            <Check className="w-10 h-10 text-white" />
          </div>
          
          <h1 className="text-4xl font-bold text-gray-900">
            {thanks?.title || "¡Felicidades por Tu Compra!"}
          </h1>
          
          <p className="text-xl text-gray-700">
            {thanks?.message || "Gracias por confiar en nosotros. Tu producto digital está listo."}
          </p>
          
          <Card className="p-6 bg-white/80 backdrop-blur-sm">
            <div className="space-y-4">
              <div className="flex items-center justify-center gap-2">
                <Gift className="w-5 h-5 text-purple-600" />
                <span className="font-semibold">Tu producto está listo</span>
              </div>
              
              <p className="text-gray-600">
                {thanks?.downloadInstructions || "Recibirás un email con el enlace de descarga en los próximos minutos."}
              </p>
              
              <Button className="bg-purple-600 hover:bg-purple-700 text-white">
                <Download className="w-4 h-4 mr-2" />
                Acceder al Área de Miembros
              </Button>
            </div>
          </Card>
          
          {thanks?.socialShare && (
            <div className="flex justify-center gap-4 pt-6">
              <Button variant="outline" size="sm">
                Compartir en Twitter
              </Button>
              <Button variant="outline" size="sm">
                Compartir en Facebook
              </Button>
            </div>
          )}
        </div>
      </div>
    );
  };

  const renderCurrentStep = () => {
    switch (steps[currentStep]) {
      case "landing":
        return renderLandingPage();
      case "checkout":
        return renderCheckoutPage();
      case "thanks":
        return renderThanksPage();
      default:
        return null;
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Button variant="outline" onClick={onBack}>
            <ArrowLeft className="w-4 h-4 mr-2" />
            Volver al Editor
          </Button>
          <div>
            <h2 className="text-2xl font-bold text-gray-900">Vista Previa del Embudo</h2>
            <p className="text-gray-600">{funnelData.name}</p>
          </div>
        </div>
        
        <div className="flex items-center gap-2">
          <Button
            variant={deviceView === "desktop" ? "default" : "outline"}
            size="sm"
            onClick={() => setDeviceView("desktop")}
          >
            <Monitor className="w-4 h-4" />
          </Button>
          <Button
            variant={deviceView === "tablet" ? "default" : "outline"}
            size="sm"
            onClick={() => setDeviceView("tablet")}
          >
            <Tablet className="w-4 h-4" />
          </Button>
          <Button
            variant={deviceView === "mobile" ? "default" : "outline"}
            size="sm"
            onClick={() => setDeviceView("mobile")}
          >
            <Smartphone className="w-4 h-4" />
          </Button>
        </div>
      </div>

      {/* Step Navigation */}
      <div className="flex items-center justify-center gap-4">
        <Button
          variant="outline"
          size="sm"
          onClick={() => setCurrentStep(Math.max(0, currentStep - 1))}
          disabled={currentStep === 0}
        >
          <ArrowLeft className="w-4 h-4" />
        </Button>
        
        <div className="flex items-center gap-2">
          {steps.map((step, index) => (
            <div key={step} className="flex items-center">
              <Badge 
                variant={index === currentStep ? "default" : "outline"}
                className="cursor-pointer"
                onClick={() => setCurrentStep(index)}
              >
                {stepNames[index]}
              </Badge>
              {index < steps.length - 1 && (
                <ArrowRight className="w-4 h-4 text-gray-400 mx-2" />
              )}
            </div>
          ))}
        </div>
        
        <Button
          variant="outline"
          size="sm"
          onClick={() => setCurrentStep(Math.min(steps.length - 1, currentStep + 1))}
          disabled={currentStep === steps.length - 1}
        >
          <ArrowRight className="w-4 h-4" />
        </Button>
      </div>

      {/* Preview Container */}
      <div className="flex justify-center">
        <motion.div 
          className={`border-2 border-gray-200 rounded-lg overflow-hidden bg-white shadow-lg ${getDeviceClass()}`}
          animate={{ width: deviceView === "mobile" ? 320 : deviceView === "tablet" ? 768 : "100%" }}
          transition={{ duration: 0.3 }}
        >
          <div className="h-full overflow-auto">
            {renderCurrentStep()}
          </div>
        </motion.div>
      </div>

      {/* URL Info */}
      {funnelData.subdomain && (
        <Card className="bg-blue-50 border-blue-200">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <ExternalLink className="w-4 h-4 text-blue-600" />
                <span className="font-medium text-blue-900">
                  {funnelData.subdomain}.embudos.app
                </span>
                <Badge variant="outline" className="text-blue-700 border-blue-300">
                  {funnelData.isPublished ? "En vivo" : "Vista previa"}
                </Badge>
              </div>
              {funnelData.isPublished && (
                <Button variant="outline" size="sm" className="text-blue-700 border-blue-300">
                  Visitar Sitio
                </Button>
              )}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
