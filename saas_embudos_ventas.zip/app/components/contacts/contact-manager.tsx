
"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { 
  Users, 
  Mail, 
  Phone, 
  MapPin, 
  Calendar,
  Search,
  Filter,
  Download,
  Plus,
  Eye,
  Edit,
  Trash2,
  UserPlus,
  TrendingUp
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface Contact {
  id: string;
  name: string;
  email: string;
  phone?: string;
  location?: string;
  status: "lead" | "prospect" | "customer" | "inactive";
  source: string;
  tags: string[];
  totalSpent: number;
  lastActivity: string;
  createdAt: string;
  notes?: string;
}

const STATUS_CONFIG = {
  lead: { label: "Lead", color: "bg-blue-100 text-blue-800", icon: UserPlus },
  prospect: { label: "Prospecto", color: "bg-yellow-100 text-yellow-800", icon: Eye },
  customer: { label: "Cliente", color: "bg-green-100 text-green-800", icon: TrendingUp },
  inactive: { label: "Inactivo", color: "bg-gray-100 text-gray-800", icon: Users }
};

export default function ContactManager() {
  const [contacts, setContacts] = useState<Contact[]>([
    {
      id: '1',
      name: 'María González',
      email: 'maria@example.com',
      phone: '+34 666 123 456',
      location: 'Madrid, España',
      status: 'customer',
      source: 'Landing Page',
      tags: ['vip', 'marketing'],
      totalSpent: 125.50,
      lastActivity: '2024-01-15',
      createdAt: '2024-01-10',
      notes: 'Cliente muy interesado en cursos avanzados'
    },
    {
      id: '2',
      name: 'Carlos Ruiz',
      email: 'carlos@example.com',
      status: 'prospect',
      source: 'Redes Sociales',
      tags: ['tech'],
      totalSpent: 0,
      lastActivity: '2024-01-14',
      createdAt: '2024-01-12'
    },
    {
      id: '3',
      name: 'Ana Martín',
      email: 'ana@example.com',
      phone: '+34 677 987 654',
      status: 'lead',
      source: 'Google Ads',
      tags: ['startup'],
      totalSpent: 0,
      lastActivity: '2024-01-13',
      createdAt: '2024-01-13'
    }
  ]);

  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [selectedContact, setSelectedContact] = useState<Contact | null>(null);
  const [showAddForm, setShowAddForm] = useState(false);

  const { toast } = useToast();

  const filteredContacts = contacts.filter(contact => {
    const matchesSearch = contact.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         contact.email.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = filterStatus === 'all' || contact.status === filterStatus;
    
    return matchesSearch && matchesStatus;
  });

  const getStatusCounts = () => {
    return {
      all: contacts.length,
      lead: contacts.filter(c => c.status === 'lead').length,
      prospect: contacts.filter(c => c.status === 'prospect').length,
      customer: contacts.filter(c => c.status === 'customer').length,
      inactive: contacts.filter(c => c.status === 'inactive').length
    };
  };

  const statusCounts = getStatusCounts();

  const handleStatusChange = async (contactId: string, newStatus: Contact['status']) => {
    try {
      const response = await fetch(`/api/contacts/${contactId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: newStatus }),
      });

      if (!response.ok) throw new Error('Error al actualizar el estado');

      setContacts(prev =>
        prev.map(c =>
          c.id === contactId 
            ? { ...c, status: newStatus, lastActivity: new Date().toISOString().split('T')[0] }
            : c
        )
      );

      toast({
        title: "Estado actualizado",
        description: `El contacto ha sido movido a ${STATUS_CONFIG[newStatus].label}`,
      });

    } catch (error) {
      toast({
        title: "Error",
        description: "No se pudo actualizar el estado del contacto",
        variant: "destructive",
      });
    }
  };

  const handleDeleteContact = async (contactId: string) => {
    if (!confirm('¿Estás seguro de que quieres eliminar este contacto?')) return;

    try {
      const response = await fetch(`/api/contacts/${contactId}`, {
        method: 'DELETE',
      });

      if (!response.ok) throw new Error('Error al eliminar el contacto');

      setContacts(prev => prev.filter(c => c.id !== contactId));
      
      toast({
        title: "Contacto eliminado",
        description: "El contacto ha sido eliminado correctamente",
      });

    } catch (error) {
      toast({
        title: "Error",
        description: "No se pudo eliminar el contacto",
        variant: "destructive",
      });
    }
  };

  const exportContacts = () => {
    const csvData = filteredContacts.map(contact => ({
      Nombre: contact.name,
      Email: contact.email,
      Teléfono: contact.phone || '',
      Estado: STATUS_CONFIG[contact.status].label,
      Origen: contact.source,
      'Total Gastado': `€${contact.totalSpent.toFixed(2)}`,
      'Última Actividad': contact.lastActivity,
      'Fecha Registro': contact.createdAt
    }));

    const csvContent = [
      Object.keys(csvData[0]).join(','),
      ...csvData.map(row => Object.values(row).join(','))
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'contactos.csv';
    a.click();
    window.URL.revokeObjectURL(url);

    toast({
      title: "Exportación completada",
      description: "Los contactos se han exportado correctamente",
    });
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Gestión de Contactos</h2>
          <p className="text-gray-600">Administra tus leads y clientes</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={exportContacts}>
            <Download className="w-4 h-4 mr-2" />
            Exportar CSV
          </Button>
          <Button
            onClick={() => setShowAddForm(true)}
            className="bg-blue-600 hover:bg-blue-700"
          >
            <Plus className="w-4 h-4 mr-2" />
            Nuevo Contacto
          </Button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
        <Card 
          className={`cursor-pointer transition-all ${filterStatus === 'all' ? 'ring-2 ring-blue-500' : ''}`}
          onClick={() => setFilterStatus('all')}
        >
          <CardContent className="p-4 text-center">
            <Users className="w-6 h-6 text-gray-600 mx-auto mb-2" />
            <p className="text-2xl font-bold">{statusCounts.all}</p>
            <p className="text-sm text-gray-600">Total</p>
          </CardContent>
        </Card>

        {Object.entries(STATUS_CONFIG).map(([status, config]) => (
          <Card 
            key={status}
            className={`cursor-pointer transition-all ${filterStatus === status ? 'ring-2 ring-blue-500' : ''}`}
            onClick={() => setFilterStatus(status)}
          >
            <CardContent className="p-4 text-center">
              <config.icon className="w-6 h-6 text-gray-600 mx-auto mb-2" />
              <p className="text-2xl font-bold">{statusCounts[status as keyof typeof statusCounts]}</p>
              <p className="text-sm text-gray-600">{config.label}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Search and Filter */}
      <Card>
        <CardContent className="p-4">
          <div className="flex items-center gap-4">
            <div className="flex-1 relative">
              <Search className="w-4 h-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
              <Input
                placeholder="Buscar contactos por nombre o email..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <Badge variant="outline" className="px-3 py-1">
              {filteredContacts.length} contacto{filteredContacts.length !== 1 ? 's' : ''}
            </Badge>
          </div>
        </CardContent>
      </Card>

      {/* Kanban Board */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {Object.entries(STATUS_CONFIG).map(([status, config]) => {
          const statusContacts = filteredContacts.filter(c => c.status === status);
          
          return (
            <Card key={status}>
              <CardHeader className="pb-3">
                <CardTitle className="flex items-center gap-2 text-sm">
                  <config.icon className="w-4 h-4" />
                  {config.label}
                  <Badge variant="outline" className="ml-auto">
                    {statusContacts.length}
                  </Badge>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <AnimatePresence>
                  {statusContacts.map((contact) => (
                    <motion.div
                      key={contact.id}
                      layout
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -10 }}
                    >
                      <Card className="cursor-pointer hover:shadow-md transition-shadow">
                        <CardContent className="p-3" onClick={() => setSelectedContact(contact)}>
                          <div className="space-y-2">
                            <div className="flex items-center justify-between">
                              <h4 className="font-medium text-sm">{contact.name}</h4>
                              <div className="flex gap-1">
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  className="h-6 w-6 p-0"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    setSelectedContact(contact);
                                  }}
                                >
                                  <Eye className="w-3 h-3" />
                                </Button>
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  className="h-6 w-6 p-0 text-red-600"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    handleDeleteContact(contact.id);
                                  }}
                                >
                                  <Trash2 className="w-3 h-3" />
                                </Button>
                              </div>
                            </div>
                            
                            <p className="text-xs text-gray-600">{contact.email}</p>
                            
                            <div className="flex items-center gap-2 text-xs text-gray-500">
                              <span>{contact.source}</span>
                              {contact.totalSpent > 0 && (
                                <Badge variant="outline" className="text-xs">
                                  €{contact.totalSpent.toFixed(2)}
                                </Badge>
                              )}
                            </div>
                            
                            {contact.tags.length > 0 && (
                              <div className="flex flex-wrap gap-1">
                                {contact.tags.slice(0, 2).map((tag) => (
                                  <Badge key={tag} variant="outline" className="text-xs">
                                    {tag}
                                  </Badge>
                                ))}
                                {contact.tags.length > 2 && (
                                  <Badge variant="outline" className="text-xs">
                                    +{contact.tags.length - 2}
                                  </Badge>
                                )}
                              </div>
                            )}
                          </div>
                        </CardContent>
                      </Card>
                    </motion.div>
                  ))}
                </AnimatePresence>
                
                {statusContacts.length === 0 && (
                  <div className="text-center py-8 text-gray-500">
                    <config.icon className="w-8 h-8 mx-auto mb-2 opacity-50" />
                    <p className="text-sm">No hay contactos</p>
                  </div>
                )}
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Contact Detail Modal */}
      <AnimatePresence>
        {selectedContact && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-white rounded-lg p-6 w-full max-w-2xl max-h-[80vh] overflow-y-auto"
            >
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h2 className="text-xl font-bold">{selectedContact.name}</h2>
                  <Badge className={STATUS_CONFIG[selectedContact.status].color}>
                    {STATUS_CONFIG[selectedContact.status].label}
                  </Badge>
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setSelectedContact(null)}
                >
                  ✕
                </Button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <h3 className="font-semibold">Información de Contacto</h3>
                  
                  <div className="space-y-3">
                    <div className="flex items-center gap-2">
                      <Mail className="w-4 h-4 text-gray-500" />
                      <span className="text-sm">{selectedContact.email}</span>
                    </div>
                    
                    {selectedContact.phone && (
                      <div className="flex items-center gap-2">
                        <Phone className="w-4 h-4 text-gray-500" />
                        <span className="text-sm">{selectedContact.phone}</span>
                      </div>
                    )}
                    
                    {selectedContact.location && (
                      <div className="flex items-center gap-2">
                        <MapPin className="w-4 h-4 text-gray-500" />
                        <span className="text-sm">{selectedContact.location}</span>
                      </div>
                    )}
                    
                    <div className="flex items-center gap-2">
                      <Calendar className="w-4 h-4 text-gray-500" />
                      <span className="text-sm">Registrado: {selectedContact.createdAt}</span>
                    </div>
                  </div>
                </div>

                <div className="space-y-4">
                  <h3 className="font-semibold">Información de Ventas</h3>
                  
                  <div className="space-y-3">
                    <div>
                      <Label className="text-sm text-gray-500">Origen</Label>
                      <p className="font-medium">{selectedContact.source}</p>
                    </div>
                    
                    <div>
                      <Label className="text-sm text-gray-500">Total Gastado</Label>
                      <p className="font-medium">€{selectedContact.totalSpent.toFixed(2)}</p>
                    </div>
                    
                    <div>
                      <Label className="text-sm text-gray-500">Última Actividad</Label>
                      <p className="font-medium">{selectedContact.lastActivity}</p>
                    </div>

                    <div>
                      <Label className="text-sm text-gray-500">Cambiar Estado</Label>
                      <select
                        value={selectedContact.status}
                        onChange={(e) => handleStatusChange(selectedContact.id, e.target.value as Contact['status'])}
                        className="w-full p-2 border rounded-md text-sm"
                      >
                        {Object.entries(STATUS_CONFIG).map(([status, config]) => (
                          <option key={status} value={status}>
                            {config.label}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>
                </div>
              </div>

              {selectedContact.tags.length > 0 && (
                <div className="mt-6">
                  <h3 className="font-semibold mb-2">Etiquetas</h3>
                  <div className="flex flex-wrap gap-2">
                    {selectedContact.tags.map((tag) => (
                      <Badge key={tag} variant="outline">
                        {tag}
                      </Badge>
                    ))}
                  </div>
                </div>
              )}

              {selectedContact.notes && (
                <div className="mt-6">
                  <h3 className="font-semibold mb-2">Notas</h3>
                  <p className="text-gray-600 bg-gray-50 p-3 rounded-lg">
                    {selectedContact.notes}
                  </p>
                </div>
              )}
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
