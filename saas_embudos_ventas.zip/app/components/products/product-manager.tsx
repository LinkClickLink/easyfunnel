
"use client";

import { useState, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { 
  Upload, 
  File, 
  Trash2, 
  Download, 
  Plus, 
  FileText,
  FileImage,
  FileVideo,
  FileAudio,
  Archive,
  Eye,
  Edit,
  Save,
  X
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface Product {
  id: string;
  name: string;
  description: string;
  fileName: string;
  fileSize: number;
  fileType: string;
  cloud_storage_path: string;
  uploadDate: string;
  downloads: number;
  isActive: boolean;
}

export default function ProductManager() {
  const [products, setProducts] = useState<Product[]>([
    {
      id: '1',
      name: 'Curso Marketing Digital',
      description: 'Curso completo de marketing digital con más de 50 lecciones',
      fileName: 'curso-marketing-digital.pdf',
      fileSize: 15680000,
      fileType: 'application/pdf',
      cloud_storage_path: 'uploads/curso-marketing.pdf',
      uploadDate: '2024-01-15',
      downloads: 127,
      isActive: true
    }
  ]);
  
  const [isUploading, setIsUploading] = useState(false);
  const [showUploadForm, setShowUploadForm] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [uploadProgress, setUploadProgress] = useState(0);
  
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();
  
  const [newProduct, setNewProduct] = useState({
    name: '',
    description: '',
    file: null as File | null
  });

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    
    // Validar tipo de archivo
    const allowedTypes = [
      'application/pdf',
      'application/zip',
      'video/mp4',
      'audio/mpeg',
      'image/jpeg',
      'image/png'
    ];
    
    if (!allowedTypes.includes(file.type)) {
      toast({
        title: "Tipo de archivo no permitido",
        description: "Solo se permiten archivos PDF, ZIP, MP4, MP3, JPG y PNG",
        variant: "destructive",
      });
      return;
    }
    
    // Validar tamaño (máximo 100MB)
    if (file.size > 100 * 1024 * 1024) {
      toast({
        title: "Archivo demasiado grande",
        description: "El archivo no debe superar los 100MB",
        variant: "destructive",
      });
      return;
    }
    
    setNewProduct(prev => ({ ...prev, file }));
  };

  const handleUploadProduct = async () => {
    if (!newProduct.name || !newProduct.file) {
      toast({
        title: "Campos requeridos",
        description: "Por favor completa todos los campos obligatorios",
        variant: "destructive",
      });
      return;
    }

    setIsUploading(true);
    setUploadProgress(0);

    try {
      // Simular progreso de subida
      const progressInterval = setInterval(() => {
        setUploadProgress(prev => {
          if (prev >= 90) {
            clearInterval(progressInterval);
            return 90;
          }
          return prev + 10;
        });
      }, 200);

      const formData = new FormData();
      formData.append('file', newProduct.file);
      formData.append('name', newProduct.name);
      formData.append('description', newProduct.description);

      const response = await fetch('/api/products/upload', {
        method: 'POST',
        body: formData,
      });

      if (!response.ok) throw new Error('Error al subir el archivo');

      const result = await response.json();
      
      const newProd: Product = {
        id: result.id || Date.now().toString(),
        name: newProduct.name,
        description: newProduct.description,
        fileName: newProduct.file.name,
        fileSize: newProduct.file.size,
        fileType: newProduct.file.type,
        cloud_storage_path: result.cloud_storage_path || `uploads/${newProduct.file.name}`,
        uploadDate: new Date().toISOString().split('T')[0],
        downloads: 0,
        isActive: true
      };

      setProducts(prev => [...prev, newProd]);
      setNewProduct({ name: '', description: '', file: null });
      setShowUploadForm(false);
      setUploadProgress(100);

      toast({
        title: "Producto subido exitosamente",
        description: `${newProduct.name} está listo para la venta`,
      });

    } catch (error) {
      toast({
        title: "Error al subir producto",
        description: "Inténtalo de nuevo más tarde",
        variant: "destructive",
      });
    } finally {
      setIsUploading(false);
      setUploadProgress(0);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  const handleDeleteProduct = async (productId: string) => {
    if (!confirm('¿Estás seguro de que quieres eliminar este producto?')) return;

    try {
      const response = await fetch(`/api/products/${productId}`, {
        method: 'DELETE',
      });

      if (!response.ok) throw new Error('Error al eliminar el producto');

      setProducts(prev => prev.filter(p => p.id !== productId));
      
      toast({
        title: "Producto eliminado",
        description: "El producto ha sido eliminado correctamente",
      });

    } catch (error) {
      toast({
        title: "Error al eliminar",
        description: "No se pudo eliminar el producto",
        variant: "destructive",
      });
    }
  };

  const handleEditProduct = (product: Product) => {
    setEditingProduct({ ...product });
  };

  const handleSaveEdit = async () => {
    if (!editingProduct) return;

    try {
      const response = await fetch(`/api/products/${editingProduct.id}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          name: editingProduct.name,
          description: editingProduct.description,
          isActive: editingProduct.isActive,
        }),
      });

      if (!response.ok) throw new Error('Error al actualizar el producto');

      setProducts(prev =>
        prev.map(p =>
          p.id === editingProduct.id ? editingProduct : p
        )
      );

      setEditingProduct(null);
      
      toast({
        title: "Producto actualizado",
        description: "Los cambios se han guardado correctamente",
      });

    } catch (error) {
      toast({
        title: "Error al actualizar",
        description: "No se pudo actualizar el producto",
        variant: "destructive",
      });
    }
  };

  const getFileIcon = (fileType: string) => {
    if (fileType.includes('pdf')) return FileText;
    if (fileType.includes('image')) return FileImage;
    if (fileType.includes('video')) return FileVideo;
    if (fileType.includes('audio')) return FileAudio;
    if (fileType.includes('zip')) return Archive;
    return File;
  };

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Gestión de Productos</h2>
          <p className="text-gray-600">Administra tus productos digitales</p>
        </div>
        <Button
          onClick={() => setShowUploadForm(true)}
          className="bg-blue-600 hover:bg-blue-700"
        >
          <Plus className="w-4 h-4 mr-2" />
          Nuevo Producto
        </Button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Total Productos</p>
                <p className="text-2xl font-bold">{products.length}</p>
              </div>
              <File className="w-8 h-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Productos Activos</p>
                <p className="text-2xl font-bold">{products.filter(p => p.isActive).length}</p>
              </div>
              <Eye className="w-8 h-8 text-green-600" />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Total Descargas</p>
                <p className="text-2xl font-bold">{products.reduce((acc, p) => acc + p.downloads, 0)}</p>
              </div>
              <Download className="w-8 h-8 text-purple-600" />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Almacenamiento</p>
                <p className="text-2xl font-bold">
                  {formatFileSize(products.reduce((acc, p) => acc + p.fileSize, 0))}
                </p>
              </div>
              <Archive className="w-8 h-8 text-orange-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Upload Form Modal */}
      <AnimatePresence>
        {showUploadForm && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-white rounded-lg p-6 w-full max-w-md"
            >
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold">Subir Nuevo Producto</h3>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setShowUploadForm(false)}
                >
                  <X className="w-4 h-4" />
                </Button>
              </div>

              <div className="space-y-4">
                <div>
                  <Label htmlFor="productName">Nombre del Producto</Label>
                  <Input
                    id="productName"
                    value={newProduct.name}
                    onChange={(e) => setNewProduct(prev => ({ ...prev, name: e.target.value }))}
                    placeholder="Ej: Mi Curso Digital"
                  />
                </div>

                <div>
                  <Label htmlFor="productDescription">Descripción</Label>
                  <Textarea
                    id="productDescription"
                    value={newProduct.description}
                    onChange={(e) => setNewProduct(prev => ({ ...prev, description: e.target.value }))}
                    placeholder="Describe tu producto..."
                    rows={3}
                  />
                </div>

                <div>
                  <Label htmlFor="productFile">Archivo del Producto</Label>
                  <Input
                    id="productFile"
                    type="file"
                    ref={fileInputRef}
                    onChange={handleFileUpload}
                    accept=".pdf,.zip,.mp4,.mp3,.jpg,.jpeg,.png"
                  />
                  <p className="text-xs text-gray-500 mt-1">
                    Formatos: PDF, ZIP, MP4, MP3, JPG, PNG (máx. 100MB)
                  </p>
                </div>

                {newProduct.file && (
                  <div className="bg-gray-50 p-3 rounded-lg">
                    <div className="flex items-center gap-2">
                      {(() => {
                        const Icon = getFileIcon(newProduct.file?.type || '');
                        return <Icon className="w-4 h-4 text-blue-600" />;
                      })()}
                      <span className="text-sm font-medium">{newProduct.file.name}</span>
                    </div>
                    <p className="text-xs text-gray-500">
                      {formatFileSize(newProduct.file.size)}
                    </p>
                  </div>
                )}

                {isUploading && (
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Subiendo archivo...</span>
                      <span>{uploadProgress}%</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div
                        className="bg-blue-600 h-2 rounded-full transition-all"
                        style={{ width: `${uploadProgress}%` }}
                      />
                    </div>
                  </div>
                )}

                <div className="flex gap-2 pt-4">
                  <Button
                    variant="outline"
                    className="flex-1"
                    onClick={() => setShowUploadForm(false)}
                    disabled={isUploading}
                  >
                    Cancelar
                  </Button>
                  <Button
                    className="flex-1 bg-blue-600 hover:bg-blue-700"
                    onClick={handleUploadProduct}
                    disabled={isUploading || !newProduct.name || !newProduct.file}
                  >
                    {isUploading ? (
                      <>
                        <Upload className="w-4 h-4 mr-2 animate-pulse" />
                        Subiendo...
                      </>
                    ) : (
                      <>
                        <Upload className="w-4 h-4 mr-2" />
                        Subir Producto
                      </>
                    )}
                  </Button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Products List */}
      <div className="space-y-4">
        {products.length === 0 ? (
          <Card>
            <CardContent className="text-center py-12">
              <File className="w-16 h-16 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-gray-700 mb-2">
                No hay productos aún
              </h3>
              <p className="text-gray-600 mb-6">
                Sube tu primer producto digital para comenzar a vender
              </p>
              <Button
                onClick={() => setShowUploadForm(true)}
                className="bg-blue-600 hover:bg-blue-700"
              >
                <Plus className="w-4 h-4 mr-2" />
                Subir Producto
              </Button>
            </CardContent>
          </Card>
        ) : (
          products.map((product) => (
            <Card key={product.id}>
              <CardContent className="p-6">
                {editingProduct?.id === product.id ? (
                  <div className="space-y-4">
                    <Input
                      value={editingProduct.name}
                      onChange={(e) => setEditingProduct(prev => prev ? { ...prev, name: e.target.value } : null)}
                      className="font-semibold"
                    />
                    <Textarea
                      value={editingProduct.description}
                      onChange={(e) => setEditingProduct(prev => prev ? { ...prev, description: e.target.value } : null)}
                      rows={2}
                    />
                    <div className="flex items-center gap-4">
                      <label className="flex items-center gap-2">
                        <input
                          type="checkbox"
                          checked={editingProduct.isActive}
                          onChange={(e) => setEditingProduct(prev => prev ? { ...prev, isActive: e.target.checked } : null)}
                        />
                        <span className="text-sm">Producto activo</span>
                      </label>
                    </div>
                    <div className="flex gap-2">
                      <Button size="sm" onClick={handleSaveEdit}>
                        <Save className="w-4 h-4 mr-2" />
                        Guardar
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setEditingProduct(null)}
                      >
                        Cancelar
                      </Button>
                    </div>
                  </div>
                ) : (
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      {(() => {
                        const Icon = getFileIcon(product.fileType);
                        return <Icon className="w-10 h-10 text-blue-600" />;
                      })()}
                      
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-1">
                          <h3 className="font-semibold text-gray-900">{product.name}</h3>
                          <Badge variant={product.isActive ? "default" : "outline"}>
                            {product.isActive ? "Activo" : "Inactivo"}
                          </Badge>
                        </div>
                        <p className="text-gray-600 text-sm mb-2">{product.description}</p>
                        <div className="flex items-center gap-4 text-xs text-gray-500">
                          <span>{product.fileName}</span>
                          <span>{formatFileSize(product.fileSize)}</span>
                          <span>{product.downloads} descargas</span>
                          <span>Subido: {product.uploadDate}</span>
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-2">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleEditProduct(product)}
                      >
                        <Edit className="w-4 h-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleDeleteProduct(product.id)}
                        className="text-red-600 hover:text-red-700"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  );
}
