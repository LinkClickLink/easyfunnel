
"use client";

import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  Download, 
  File, 
  FileText,
  FileImage,
  FileVideo,
  FileAudio,
  Archive,
  Calendar,
  CheckCircle,
  Clock,
  User,
  Mail
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface Purchase {
  id: string;
  productName: string;
  purchaseDate: string;
  amount: number;
  status: "completed" | "pending" | "refunded";
  downloadCount: number;
  maxDownloads: number;
  files: {
    id: string;
    name: string;
    type: string;
    size: number;
    cloud_storage_path: string;
  }[];
}

interface MemberData {
  id: string;
  name: string;
  email: string;
  joinDate: string;
  totalPurchases: number;
  totalSpent: number;
}

export default function MembersArea() {
  const [memberData, setMemberData] = useState<MemberData>({
    id: '1',
    name: 'Juan Pérez',
    email: 'juan@example.com',
    joinDate: '2024-01-15',
    totalPurchases: 2,
    totalSpent: 125.50
  });

  const [purchases, setPurchases] = useState<Purchase[]>([
    {
      id: '1',
      productName: 'Curso Marketing Digital Completo',
      purchaseDate: '2024-01-15',
      amount: 97.00,
      status: 'completed',
      downloadCount: 3,
      maxDownloads: 5,
      files: [
        {
          id: '1',
          name: 'Modulo-1-Fundamentos.pdf',
          type: 'application/pdf',
          size: 2048000,
          cloud_storage_path: 'uploads/modulo1.pdf'
        },
        {
          id: '2',
          name: 'Plantillas-Marketing.zip',
          type: 'application/zip',
          size: 15680000,
          cloud_storage_path: 'uploads/plantillas.zip'
        },
        {
          id: '3',
          name: 'Video-Introduccion.mp4',
          type: 'video/mp4',
          size: 45000000,
          cloud_storage_path: 'uploads/intro.mp4'
        }
      ]
    },
    {
      id: '2',
      productName: 'Guía Redes Sociales 2024',
      purchaseDate: '2024-01-20',
      amount: 28.50,
      status: 'completed',
      downloadCount: 1,
      maxDownloads: 3,
      files: [
        {
          id: '4',
          name: 'Guia-Redes-Sociales-2024.pdf',
          type: 'application/pdf',
          size: 3200000,
          cloud_storage_path: 'uploads/guia-rrss.pdf'
        }
      ]
    }
  ]);

  const [downloadingFiles, setDownloadingFiles] = useState<Set<string>>(new Set());
  const { toast } = useToast();

  const getFileIcon = (fileType: string) => {
    if (fileType.includes('pdf')) return FileText;
    if (fileType.includes('image')) return FileImage;
    if (fileType.includes('video')) return FileVideo;
    if (fileType.includes('audio')) return FileAudio;
    if (fileType.includes('zip')) return Archive;
    return File;
  };

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const handleDownload = async (purchaseId: string, fileId: string, fileName: string, cloudStoragePath: string) => {
    // Verificar límite de descargas
    const purchase = purchases.find(p => p.id === purchaseId);
    if (!purchase) return;

    if (purchase.downloadCount >= purchase.maxDownloads) {
      toast({
        title: "Límite de descargas alcanzado",
        description: "Has alcanzado el máximo de descargas para este producto",
        variant: "destructive",
      });
      return;
    }

    setDownloadingFiles(prev => new Set(prev).add(fileId));

    try {
      const response = await fetch(`/api/members/download`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          purchaseId,
          fileId,
          cloudStoragePath
        }),
      });

      if (!response.ok) throw new Error('Error al generar el enlace de descarga');

      const { downloadUrl } = await response.json();

      // Crear enlace temporal para descarga
      const link = document.createElement('a');
      link.href = downloadUrl;
      link.download = fileName;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);

      // Actualizar contador de descargas
      setPurchases(prev =>
        prev.map(p =>
          p.id === purchaseId
            ? { ...p, downloadCount: p.downloadCount + 1 }
            : p
        )
      );

      toast({
        title: "Descarga iniciada",
        description: `${fileName} se está descargando`,
      });

    } catch (error) {
      toast({
        title: "Error en la descarga",
        description: "No se pudo descargar el archivo. Inténtalo de nuevo.",
        variant: "destructive",
      });
    } finally {
      setDownloadingFiles(prev => {
        const newSet = new Set(prev);
        newSet.delete(fileId);
        return newSet;
      });
    }
  };

  const getStatusColor = (status: Purchase['status']) => {
    switch (status) {
      case 'completed':
        return 'bg-green-100 text-green-800';
      case 'pending':
        return 'bg-yellow-100 text-yellow-800';
      case 'refunded':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusLabel = (status: Purchase['status']) => {
    switch (status) {
      case 'completed':
        return 'Completado';
      case 'pending':
        return 'Pendiente';
      case 'refunded':
        return 'Reembolsado';
      default:
        return 'Desconocido';
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 p-4">
      <div className="max-w-6xl mx-auto space-y-6">
        {/* Header */}
        <div className="text-center py-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            Área de Miembros
          </h1>
          <p className="text-gray-600">
            Accede a todos tus productos digitales
          </p>
        </div>

        {/* Member Profile */}
        <Card className="bg-white/70 backdrop-blur-sm border-0 shadow-lg">
          <CardContent className="p-6">
            <div className="flex items-center gap-6">
              <div className="w-16 h-16 bg-gradient-to-br from-blue-600 to-purple-600 rounded-full flex items-center justify-center">
                <User className="w-8 h-8 text-white" />
              </div>
              <div className="flex-1">
                <h2 className="text-xl font-bold text-gray-900">{memberData.name}</h2>
                <p className="text-gray-600 flex items-center gap-2">
                  <Mail className="w-4 h-4" />
                  {memberData.email}
                </p>
                <p className="text-sm text-gray-500 mt-1">
                  Miembro desde: {memberData.joinDate}
                </p>
              </div>
              <div className="text-right">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-2xl font-bold text-gray-900">{memberData.totalPurchases}</p>
                    <p className="text-sm text-gray-600">Productos</p>
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-gray-900">€{memberData.totalSpent.toFixed(2)}</p>
                    <p className="text-sm text-gray-600">Invertido</p>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Purchases */}
        <div className="space-y-6">
          <h2 className="text-2xl font-bold text-gray-900">Mis Productos</h2>
          
          {purchases.map((purchase) => (
            <motion.div
              key={purchase.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="space-y-4"
            >
              <Card className="bg-white/70 backdrop-blur-sm border-0 shadow-lg">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle className="text-lg">{purchase.productName}</CardTitle>
                      <CardDescription className="flex items-center gap-4 mt-2">
                        <span className="flex items-center gap-1">
                          <Calendar className="w-4 h-4" />
                          {purchase.purchaseDate}
                        </span>
                        <span>€{purchase.amount.toFixed(2)}</span>
                        <Badge className={getStatusColor(purchase.status)}>
                          {getStatusLabel(purchase.status)}
                        </Badge>
                      </CardDescription>
                    </div>
                    <div className="text-right">
                      <p className="text-sm text-gray-600">
                        Descargas: {purchase.downloadCount}/{purchase.maxDownloads}
                      </p>
                      <div className="w-24 bg-gray-200 rounded-full h-2 mt-1">
                        <div
                          className="bg-blue-600 h-2 rounded-full"
                          style={{
                            width: `${(purchase.downloadCount / purchase.maxDownloads) * 100}%`
                          }}
                        />
                      </div>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {purchase.files.map((file) => {
                      const Icon = getFileIcon(file.type);
                      const isDownloading = downloadingFiles.has(file.id);
                      const canDownload = purchase.downloadCount < purchase.maxDownloads && purchase.status === 'completed';
                      
                      return (
                        <Card key={file.id} className="bg-white/50">
                          <CardContent className="p-4">
                            <div className="flex items-center gap-3 mb-3">
                              <Icon className="w-8 h-8 text-blue-600" />
                              <div className="flex-1 min-w-0">
                                <h4 className="font-medium text-sm truncate">{file.name}</h4>
                                <p className="text-xs text-gray-500">{formatFileSize(file.size)}</p>
                              </div>
                            </div>
                            
                            <Button
                              className="w-full"
                              size="sm"
                              disabled={!canDownload || isDownloading}
                              onClick={() => handleDownload(purchase.id, file.id, file.name, file.cloud_storage_path)}
                            >
                              {isDownloading ? (
                                <>
                                  <Clock className="w-4 h-4 mr-2 animate-pulse" />
                                  Descargando...
                                </>
                              ) : canDownload ? (
                                <>
                                  <Download className="w-4 h-4 mr-2" />
                                  Descargar
                                </>
                              ) : purchase.status !== 'completed' ? (
                                <>
                                  <Clock className="w-4 h-4 mr-2" />
                                  Procesando...
                                </>
                              ) : (
                                <>
                                  <CheckCircle className="w-4 h-4 mr-2" />
                                  Sin descargas
                                </>
                              )}
                            </Button>
                          </CardContent>
                        </Card>
                      );
                    })}
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        {purchases.length === 0 && (
          <Card className="bg-white/70 backdrop-blur-sm border-0 shadow-lg">
            <CardContent className="text-center py-12">
              <File className="w-16 h-16 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-gray-700 mb-2">
                No tienes productos aún
              </h3>
              <p className="text-gray-600 mb-6">
                Cuando realices una compra, tus productos aparecerán aquí
              </p>
              <Button className="bg-blue-600 hover:bg-blue-700">
                Explorar Productos
              </Button>
            </CardContent>
          </Card>
        )}

        {/* Footer */}
        <div className="text-center py-8">
          <p className="text-sm text-gray-500">
            ¿Necesitas ayuda? Contacta con soporte: soporte@embudos.app
          </p>
        </div>
      </div>
    </div>
  );
}
