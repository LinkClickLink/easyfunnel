
"use client";

import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { 
  Mail, 
  Send, 
  Edit, 
  Eye, 
  Copy,
  Save,
  Plus
} from "lucide-react";

interface EmailTemplate {
  id: string;
  name: string;
  subject: string;
  content: string;
  type: "welcome" | "purchase" | "download" | "follow-up";
  isActive: boolean;
}

const EMAIL_TYPES = {
  welcome: { label: "Bienvenida", color: "bg-blue-100 text-blue-800" },
  purchase: { label: "Compra", color: "bg-green-100 text-green-800" },
  download: { label: "Descarga", color: "bg-purple-100 text-purple-800" },
  "follow-up": { label: "Seguimiento", color: "bg-orange-100 text-orange-800" }
};

export default function EmailTemplates() {
  const [templates, setTemplates] = useState<EmailTemplate[]>([
    {
      id: '1',
      name: 'Email de Bienvenida',
      subject: '¡Bienvenido a nuestra comunidad!',
      content: `Hola {{nombre}},

¡Gracias por unirte a nuestra comunidad!

Estamos emocionados de tenerte con nosotros y queremos asegurarnos de que tengas la mejor experiencia posible.

En los próximos días, recibirás contenido exclusivo y ofertas especiales.

¡Prepárate para transformar tu negocio!

Saludos,
El equipo de {{empresa}}`,
      type: 'welcome',
      isActive: true
    },
    {
      id: '2',
      name: 'Confirmación de Compra',
      subject: 'Tu compra ha sido confirmada - {{producto}}',
      content: `¡Hola {{nombre}}!

¡Gracias por tu compra de {{producto}}!

Tu pedido ha sido procesado exitosamente. Aquí tienes los detalles:

- Producto: {{producto}}
- Precio: €{{precio}}
- Fecha: {{fecha}}

Puedes descargar tu producto aquí: {{enlace_descarga}}

Si tienes alguna pregunta, no dudes en contactarnos.

¡Disfruta tu nueva compra!

Saludos,
El equipo de {{empresa}}`,
      type: 'purchase',
      isActive: true
    }
  ]);

  const [editingTemplate, setEditingTemplate] = useState<EmailTemplate | null>(null);

  const handleEdit = (template: EmailTemplate) => {
    setEditingTemplate({ ...template });
  };

  const handleSave = () => {
    if (!editingTemplate) return;

    setTemplates(prev =>
      prev.map(t =>
        t.id === editingTemplate.id ? editingTemplate : t
      )
    );

    setEditingTemplate(null);
  };

  const handleCancel = () => {
    setEditingTemplate(null);
  };

  const sendTestEmail = async (template: EmailTemplate) => {
    // Here would be the logic to send a test email
    console.log('Sending test email for template:', template.name);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Plantillas de Email</h2>
          <p className="text-gray-600">Gestiona los emails automáticos de tu embudo</p>
        </div>
        <Button className="bg-blue-600 hover:bg-blue-700">
          <Plus className="w-4 h-4 mr-2" />
          Nueva Plantilla
        </Button>
      </div>

      {/* Templates List */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {templates.map((template) => (
          <Card key={template.id}>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="text-lg">{template.name}</CardTitle>
                  <CardDescription className="mt-2">
                    <Badge className={EMAIL_TYPES[template.type].color}>
                      {EMAIL_TYPES[template.type].label}
                    </Badge>
                    <Badge 
                      variant={template.isActive ? "default" : "outline"}
                      className="ml-2"
                    >
                      {template.isActive ? "Activo" : "Inactivo"}
                    </Badge>
                  </CardDescription>
                </div>
                <div className="flex gap-2">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleEdit(template)}
                  >
                    <Edit className="w-4 h-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => sendTestEmail(template)}
                  >
                    <Send className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div>
                  <Label className="text-sm font-medium text-gray-600">Asunto:</Label>
                  <p className="text-sm">{template.subject}</p>
                </div>
                <div>
                  <Label className="text-sm font-medium text-gray-600">Vista previa:</Label>
                  <p className="text-sm text-gray-600 line-clamp-3">
                    {template.content.substring(0, 150)}...
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Edit Modal */}
      {editingTemplate && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-lg p-6 w-full max-w-2xl max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-semibold">Editar Plantilla</h3>
              <Button
                variant="ghost"
                size="sm"
                onClick={handleCancel}
              >
                ✕
              </Button>
            </div>

            <div className="space-y-4">
              <div>
                <Label htmlFor="templateName">Nombre de la Plantilla</Label>
                <Input
                  id="templateName"
                  value={editingTemplate.name}
                  onChange={(e) => setEditingTemplate(prev => 
                    prev ? { ...prev, name: e.target.value } : null
                  )}
                />
              </div>

              <div>
                <Label htmlFor="templateSubject">Asunto</Label>
                <Input
                  id="templateSubject"
                  value={editingTemplate.subject}
                  onChange={(e) => setEditingTemplate(prev => 
                    prev ? { ...prev, subject: e.target.value } : null
                  )}
                />
              </div>

              <div>
                <Label htmlFor="templateType">Tipo</Label>
                <select
                  id="templateType"
                  value={editingTemplate.type}
                  onChange={(e) => setEditingTemplate(prev => 
                    prev ? { ...prev, type: e.target.value as EmailTemplate['type'] } : null
                  )}
                  className="w-full p-2 border rounded-md"
                >
                  {Object.entries(EMAIL_TYPES).map(([value, config]) => (
                    <option key={value} value={value}>
                      {config.label}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <Label htmlFor="templateContent">Contenido</Label>
                <Textarea
                  id="templateContent"
                  value={editingTemplate.content}
                  onChange={(e) => setEditingTemplate(prev => 
                    prev ? { ...prev, content: e.target.value } : null
                  )}
                  rows={10}
                />
                <p className="text-xs text-gray-500 mt-1">
                  Variables disponibles: {`{{nombre}}, {{email}}, {{producto}}, {{precio}}, {{fecha}}, {{empresa}}, {{enlace_descarga}}`}
                </p>
              </div>

              <div className="flex items-center gap-2">
                <input
                  type="checkbox"
                  id="templateActive"
                  checked={editingTemplate.isActive}
                  onChange={(e) => setEditingTemplate(prev => 
                    prev ? { ...prev, isActive: e.target.checked } : null
                  )}
                />
                <Label htmlFor="templateActive">Plantilla activa</Label>
              </div>

              <div className="flex gap-2 pt-4">
                <Button
                  variant="outline"
                  className="flex-1"
                  onClick={handleCancel}
                >
                  Cancelar
                </Button>
                <Button
                  className="flex-1 bg-blue-600 hover:bg-blue-700"
                  onClick={handleSave}
                >
                  <Save className="w-4 h-4 mr-2" />
                  Guardar
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Variables Reference */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Variables Disponibles</CardTitle>
          <CardDescription>
            Usa estas variables en tus plantillas para personalizar los emails
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <h4 className="font-medium mb-2">Datos del Cliente:</h4>
              <ul className="space-y-1 text-sm text-gray-600">
                <li><code className="bg-gray-100 px-1 rounded">{'{{nombre}}'}</code> - Nombre del cliente</li>
                <li><code className="bg-gray-100 px-1 rounded">{'{{email}}'}</code> - Email del cliente</li>
              </ul>
            </div>
            <div>
              <h4 className="font-medium mb-2">Datos del Producto:</h4>
              <ul className="space-y-1 text-sm text-gray-600">
                <li><code className="bg-gray-100 px-1 rounded">{'{{producto}}'}</code> - Nombre del producto</li>
                <li><code className="bg-gray-100 px-1 rounded">{'{{precio}}'}</code> - Precio del producto</li>
                <li><code className="bg-gray-100 px-1 rounded">{'{{enlace_descarga}}'}</code> - Enlace de descarga</li>
              </ul>
            </div>
            <div>
              <h4 className="font-medium mb-2">Datos Generales:</h4>
              <ul className="space-y-1 text-sm text-gray-600">
                <li><code className="bg-gray-100 px-1 rounded">{'{{fecha}}'}</code> - Fecha actual</li>
                <li><code className="bg-gray-100 px-1 rounded">{'{{empresa}}'}</code> - Nombre de tu empresa</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
