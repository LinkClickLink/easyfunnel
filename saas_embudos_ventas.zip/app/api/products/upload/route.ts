
import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { uploadFile } from "@/lib/s3";

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session) {
      return NextResponse.json({ error: "No autorizado" }, { status: 401 });
    }

    const formData = await request.formData();
    const file = formData.get('file') as File;
    const name = formData.get('name') as string;
    const description = formData.get('description') as string;

    if (!file || !name) {
      return NextResponse.json(
        { error: "Archivo y nombre son requeridos" },
        { status: 400 }
      );
    }

    // Convert file to buffer
    const buffer = Buffer.from(await file.arrayBuffer());
    
    // Upload to S3
    const cloud_storage_path = await uploadFile(buffer, file.name);

    // Here you would save to database
    // For now, we'll return mock data
    const productId = Date.now().toString();

    return NextResponse.json({
      id: productId,
      name,
      description,
      fileName: file.name,
      fileSize: file.size,
      fileType: file.type,
      cloud_storage_path,
      success: true
    });

  } catch (error) {
    console.error('Error uploading product:', error);
    return NextResponse.json(
      { error: "Error interno del servidor" },
      { status: 500 }
    );
  }
}
