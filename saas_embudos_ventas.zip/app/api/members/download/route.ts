
import { NextRequest, NextResponse } from "next/server";
import { downloadFile } from "@/lib/s3";

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { purchaseId, fileId, cloudStoragePath } = body;

    if (!purchaseId || !fileId || !cloudStoragePath) {
      return NextResponse.json(
        { error: "Parámetros faltantes" },
        { status: 400 }
      );
    }

    // Here you would verify the purchase and download permissions
    // For now, we'll just generate the download URL
    
    const downloadUrl = await downloadFile(cloudStoragePath);

    return NextResponse.json({
      downloadUrl,
      success: true
    });

  } catch (error) {
    console.error('Error generating download URL:', error);
    return NextResponse.json(
      { error: "Error interno del servidor" },
      { status: 500 }
    );
  }
}
