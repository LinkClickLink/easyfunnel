
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { redirect } from "next/navigation";
import { prisma } from "@/lib/db";
import DashboardMain from "@/components/dashboard/dashboard-main";

export const dynamic = "force-dynamic";

async function getDashboardData(userId: string) {
  try {
    // Obtener o crear el embudo del usuario
    let funnel = await prisma.funnel.findUnique({
      where: { userId },
      include: {
        pages: {
          orderBy: { order: 'asc' }
        },
        products: {
          include: {
            _count: {
              select: { orderItems: true }
            }
          }
        },
        orders: {
          include: {
            orderItems: {
              include: {
                product: true
              }
            },
            contact: true
          },
          orderBy: { createdAt: 'desc' }
        },
        contacts: {
          orderBy: { createdAt: 'desc' }
        },
        _count: {
          select: {
            orders: true,
            contacts: true
          }
        }
      }
    });

    // Si no existe el embudo, crear uno por defecto
    if (!funnel) {
      funnel = await prisma.funnel.create({
        data: {
          userId,
          name: 'Mi Embudo Digital',
          description: 'Mi primer embudo de ventas',
          isActive: false,
        },
        include: {
          pages: {
            orderBy: { order: 'asc' }
          },
          products: {
            include: {
              _count: {
                select: { orderItems: true }
              }
            }
          },
          orders: {
            include: {
              orderItems: {
                include: {
                  product: true
                }
              },
              contact: true
            },
            orderBy: { createdAt: 'desc' }
          },
          contacts: {
            orderBy: { createdAt: 'desc' }
          },
          _count: {
            select: {
              orders: true,
              contacts: true
            }
          }
        }
      });
    }

    // Calcular estadísticas
    const totalRevenue = funnel.orders
      .filter(order => order.status === 'PAID')
      .reduce((sum, order) => sum + Number(order.total), 0);

    const totalOrders = funnel._count.orders;
    const totalContacts = funnel._count.contacts;
    const conversionRate = totalContacts > 0 ? (totalOrders / totalContacts) * 100 : 0;

    // Ingresos mensuales
    const monthlyRevenue = getMonthlyRevenue(funnel.orders);

    return {
      funnel,
      stats: {
        totalOrders,
        totalRevenue,
        totalContacts,
        conversionRate,
        recentOrders: funnel.orders.slice(0, 5),
        monthlyRevenue
      }
    };
  } catch (error) {
    console.error('Error getting dashboard data:', error);
    throw error;
  }
}

function getMonthlyRevenue(orders: any[]) {
  const months = [
    'Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun',
    'Jul', 'Ago', 'Sep', 'Oct', 'Nov', 'Dic'
  ];

  const currentYear = new Date().getFullYear();
  const monthlyData = months.map((month, index) => ({
    month,
    revenue: 0,
    orders: 0
  }));

  orders
    .filter(order => order.status === 'PAID' && new Date(order.createdAt).getFullYear() === currentYear)
    .forEach(order => {
      const monthIndex = new Date(order.createdAt).getMonth();
      monthlyData[monthIndex].revenue += Number(order.total);
      monthlyData[monthIndex].orders += 1;
    });

  return monthlyData;
}

export default async function DashboardPage() {
  const session = await getServerSession(authOptions);
  
  if (!session?.user?.id) {
    redirect("/auth/login");
  }

  const dashboardData = await getDashboardData(session.user.id);

  return (
    <DashboardMain 
      funnel={dashboardData.funnel}
      stats={dashboardData.stats}
      user={session.user}
    />
  );
}
