
# 📋 Guía de Instalación Completa

Esta guía te llevará paso a paso desde cero hasta tener tu SaaS de embudos de ventas funcionando en tu propio servidor.

## 🔧 Requisitos Previos

### Sistema Operativo
- Ubuntu 20.04+ o CentOS 8+ (recomendado)
- Al menos 2GB RAM y 20GB almacenamiento
- Conexión SSH al servidor

### Servicios Externos Necesarios
- Cuenta AWS (para S3)
- Cuenta Stripe (para pagos)
- Dominio propio (opcional pero recomendado)

## 🚀 Instalación Paso a Paso

### 1. Preparar el Servidor

#### Actualizar el sistema
```bash
sudo apt update && sudo apt upgrade -y
```

#### Instalar Node.js 18+
```bash
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt-get install -y nodejs
```

#### Instalar Yarn
```bash
npm install -g yarn
```

#### Instalar PostgreSQL
```bash
sudo apt install postgresql postgresql-contrib
sudo systemctl start postgresql
sudo systemctl enable postgresql
```

#### Instalar PM2 (gestor de procesos)
```bash
npm install -g pm2
```

#### Instalar Nginx (proxy reverso)
```bash
sudo apt install nginx
sudo systemctl start nginx
sudo systemctl enable nginx
```

### 2. Configurar PostgreSQL

#### Crear base de datos y usuario
```bash
sudo -u postgres psql

-- En el prompt de PostgreSQL:
CREATE DATABASE embudos_ventas;
CREATE USER embudos_user WITH ENCRYPTED PASSWORD 'tu_password_seguro_aqui';
GRANT ALL PRIVILEGES ON DATABASE embudos_ventas TO embudos_user;
\q
```

### 3. Clonar y Configurar la Aplicación

#### Clonar el repositorio
```bash
cd /var/www
sudo git clone https://github.com/tu-usuario/saas-embudos-ventas.git
sudo chown -R $USER:$USER saas-embudos-ventas
cd saas-embudos-ventas
```

#### Instalar dependencias
```bash
cd app
yarn install
```

#### Configurar variables de entorno
```bash
cp .env.example .env
nano .env
```

Edita el archivo `.env` con tus credenciales:
```env
# Base de datos
DATABASE_URL="postgresql://embudos_user:tu_password_seguro_aqui@localhost:5432/embudos_ventas"

# NextAuth
NEXTAUTH_URL="https://tu-dominio.com"
NEXTAUTH_SECRET="genera_un_secret_super_seguro_de_32_caracteres_minimo_aqui"

# AWS S3
AWS_REGION="us-west-2"
AWS_BUCKET_NAME="tu-bucket-s3"
AWS_ACCESS_KEY_ID="AKIA..."
AWS_SECRET_ACCESS_KEY="tu-secret-key"

# Stripe
STRIPE_PUBLISHABLE_KEY="pk_live_..."
STRIPE_SECRET_KEY="sk_live_..."
```

### 4. Configurar AWS S3

#### Crear bucket S3
1. Ve a AWS Console → S3
2. Crear nuevo bucket (ej: `mi-saas-embudos-files`)
3. Configurar permisos públicos de lectura
4. Configurar CORS:

```json
[
    {
        "AllowedHeaders": ["*"],
        "AllowedMethods": ["GET", "PUT", "POST", "DELETE"],
        "AllowedOrigins": ["https://tu-dominio.com"],
        "ExposeHeaders": []
    }
]
```

#### Crear usuario IAM
1. Ve a AWS Console → IAM
2. Crear nuevo usuario con acceso programático
3. Adjuntar política S3FullAccess
4. Guardar Access Key ID y Secret Access Key

### 5. Configurar Stripe

#### Crear cuenta y obtener claves
1. Regístrate en [Stripe](https://stripe.com)
2. Ve a Developers → API Keys
3. Copia las claves Publishable y Secret

### 6. Construir y Ejecutar la Aplicación

#### Generar cliente Prisma y ejecutar migraciones
```bash
yarn prisma generate
yarn prisma migrate deploy
```

#### Construir la aplicación
```bash
yarn build
```

#### Iniciar con PM2
```bash
pm2 start yarn --name "embudos-saas" -- start
pm2 startup
pm2 save
```

### 7. Configurar Nginx

#### Crear configuración del sitio
```bash
sudo nano /etc/nginx/sites-available/embudos-saas
```

Contenido:
```nginx
server {
    listen 80;
    server_name tu-dominio.com www.tu-dominio.com;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }
}
```

#### Activar el sitio
```bash
sudo ln -s /etc/nginx/sites-available/embudos-saas /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl reload nginx
```

### 8. Configurar SSL con Let's Encrypt

#### Instalar Certbot
```bash
sudo apt install certbot python3-certbot-nginx
```

#### Obtener certificado SSL
```bash
sudo certbot --nginx -d tu-dominio.com -d www.tu-dominio.com
```

### 9. Configurar Firewall

```bash
sudo ufw allow ssh
sudo ufw allow 'Nginx Full'
sudo ufw enable
```

## 🔍 Verificación

### Comprobar que todo funciona
1. Ve a `https://tu-dominio.com`
2. Deberías ver la landing page
3. Registra una cuenta de prueba
4. Accede al dashboard
5. Prueba subir un producto
6. Verifica que el área de miembros funcione

### Comandos útiles para debugging
```bash
# Ver logs de la aplicación
pm2 logs embudos-saas

# Ver estado de los servicios
pm2 status
sudo systemctl status nginx
sudo systemctl status postgresql

# Reiniciar servicios
pm2 restart embudos-saas
sudo systemctl restart nginx

# Ver logs del sistema
tail -f /var/log/nginx/error.log
```

## 🔒 Configuración de Seguridad

### Configurar backups automáticos
```bash
# Crear script de backup
sudo nano /root/backup-embudos.sh
```

Contenido del script:
```bash
#!/bin/bash
BACKUP_DIR="/var/backups/embudos-saas"
DATE=$(date +%Y%m%d-%H%M%S)

mkdir -p $BACKUP_DIR

# Backup de base de datos
pg_dump -h localhost -U embudos_user embudos_ventas > "$BACKUP_DIR/db-backup-$DATE.sql"

# Backup de archivos
tar -czf "$BACKUP_DIR/files-backup-$DATE.tar.gz" /var/www/saas-embudos-ventas

# Mantener solo últimos 7 backups
find $BACKUP_DIR -name "*.sql" -mtime +7 -delete
find $BACKUP_DIR -name "*.tar.gz" -mtime +7 -delete
```

#### Programar backup diario
```bash
sudo chmod +x /root/backup-embudos.sh
sudo crontab -e

# Añadir línea:
0 2 * * * /root/backup-embudos.sh
```

### Configurar monitoreo
```bash
# Instalar htop para monitoreo
sudo apt install htop

# Monitorear uso de recursos
htop

# Ver uso de disco
df -h

# Ver procesos de Node.js
ps aux | grep node
```

## 🐛 Solución de Problemas Comunes

### Error de conexión a base de datos
```bash
# Verificar que PostgreSQL está corriendo
sudo systemctl status postgresql

# Verificar conexión
sudo -u postgres psql -c "SELECT version();"

# Resetear password si es necesario
sudo -u postgres psql
\password embudos_user
```

### Error de permisos de archivos
```bash
sudo chown -R $USER:$USER /var/www/saas-embudos-ventas
sudo chmod -R 755 /var/www/saas-embudos-ventas
```

### Error de memoria insuficiente
```bash
# Crear swap file
sudo fallocate -l 2G /swapfile
sudo chmod 600 /swapfile
sudo mkswap /swapfile
sudo swapon /swapfile

# Hacer permanente
echo '/swapfile none swap sw 0 0' | sudo tee -a /etc/fstab
```

### Error de puertos ocupados
```bash
# Ver qué usa el puerto 3000
sudo lsof -i :3000

# Matar proceso si es necesario
sudo kill -9 PID_DEL_PROCESO
```

## 📱 Configuración Adicional

### Configurar dominio personalizado
1. Apunta tu dominio a la IP del servidor
2. Actualiza `NEXTAUTH_URL` en `.env`
3. Regenera el certificado SSL
4. Reinicia los servicios

### Configurar email SMTP
```env
# En .env
SMTP_HOST="smtp.gmail.com"
SMTP_PORT="587"
SMTP_USER="tu-email@gmail.com"
SMTP_PASS="tu-app-password"
SMTP_FROM="noreply@tu-dominio.com"
```

### Configurar analytics
```env
# En .env
GOOGLE_ANALYTICS_ID="GA_TRACKING_ID"
FACEBOOK_PIXEL_ID="FB_PIXEL_ID"
```

## ✅ Lista de Verificación Post-Instalación

- [ ] Aplicación accesible vía HTTPS
- [ ] Autenticación funcionando
- [ ] Subida de archivos a S3 operativa
- [ ] Pagos con Stripe configurados
- [ ] Emails enviándose correctamente
- [ ] Backups automatizados configurados
- [ ] Monitoreo básico en funcionamiento
- [ ] Certificado SSL válido y renovable
- [ ] Firewall configurado correctamente

¡Felicidades! Tu SaaS de embudos de ventas ya está operativo. 🎉
