
#!/bin/bash

# Script de configuración inicial para desarrollo local
set -e

echo "🚀 Configurando el entorno de desarrollo para SaaS Embudos de Ventas..."

# Colores para output
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

log_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

log_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Verificar que Node.js está instalado
if ! command -v node &> /dev/null; then
    log_error "Node.js no está instalado. Por favor, instala Node.js 18+ primero."
    exit 1
fi

# Verificar versión de Node.js
NODE_VERSION=$(node -v | cut -d'v' -f2 | cut -d'.' -f1)
if [ "$NODE_VERSION" -lt 18 ]; then
    log_error "Se requiere Node.js 18 o superior. Versión actual: $(node -v)"
    exit 1
fi

log_info "Node.js $(node -v) detectado ✓"

# Verificar que Yarn está instalado
if ! command -v yarn &> /dev/null; then
    log_warn "Yarn no está instalado. Instalando Yarn..."
    npm install -g yarn
fi

log_info "Yarn $(yarn -v) detectado ✓"

# Ir al directorio de la aplicación
cd app

# Instalar dependencias
log_info "Instalando dependencias..."
yarn install

# Copiar archivo de variables de entorno si no existe
if [ ! -f ".env" ]; then
    log_info "Copiando archivo de variables de entorno..."
    cp .env.example .env
    log_warn "¡IMPORTANTE! Edita el archivo .env con tus credenciales antes de continuar."
else
    log_info "Archivo .env ya existe ✓"
fi

# Verificar si PostgreSQL está ejecutándose
if command -v psql &> /dev/null; then
    log_info "PostgreSQL detectado ✓"
    
    # Intentar generar el cliente Prisma
    log_info "Generando cliente Prisma..."
    yarn prisma generate || log_warn "No se pudo generar el cliente Prisma. Verifica tu DATABASE_URL en .env"
    
    # Intentar ejecutar migraciones
    log_info "Ejecutando migraciones de base de datos..."
    yarn prisma migrate dev || log_warn "No se pudieron ejecutar las migraciones. Verifica tu configuración de base de datos."
else
    log_warn "PostgreSQL no detectado. Instálalo y configúralo antes de continuar."
fi

# Verificar construcción del proyecto
log_info "Verificando que el proyecto se puede construir..."
if yarn build; then
    log_info "✅ Proyecto construido exitosamente"
else
    log_error "❌ Error al construir el proyecto. Revisa los mensajes de error arriba."
    exit 1
fi

echo ""
echo "🎉 ¡Configuración completada!"
echo ""
echo "📋 Próximos pasos:"
echo "1. Edita el archivo app/.env con tus credenciales"
echo "2. Configura tu base de datos PostgreSQL"
echo "3. Configura AWS S3 para almacenamiento de archivos"
echo "4. Configura Stripe para procesamiento de pagos"
echo ""
echo "🚀 Para iniciar el servidor de desarrollo:"
echo "   cd app && yarn dev"
echo ""
echo "🌐 La aplicación estará disponible en: http://localhost:3000"
echo ""
echo "📚 Consulta INSTALLATION.md para instrucciones detalladas"
