
#!/bin/bash

# Script de backup para producción
set -e

# Configuración
BACKUP_DIR="/var/backups/saas-embudos-ventas"
APP_DIR="/var/www/saas-embudos-ventas"
DATE=$(date +%Y%m%d-%H%M%S)
RETENTION_DAYS=7

# Colores
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

log_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

log_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Crear directorio de backup
mkdir -p "$BACKUP_DIR"

log_info "🔄 Iniciando backup del SaaS Embudos de Ventas..."

# Backup de base de datos
if [ -n "$DATABASE_URL" ]; then
    log_info "📊 Creando backup de base de datos..."
    pg_dump "$DATABASE_URL" > "$BACKUP_DIR/database-backup-$DATE.sql"
    
    # Comprimir backup de DB
    gzip "$BACKUP_DIR/database-backup-$DATE.sql"
    log_info "✅ Backup de base de datos completado: database-backup-$DATE.sql.gz"
else
    log_warn "⚠️  DATABASE_URL no encontrada en variables de entorno"
fi

# Backup de archivos de la aplicación (excluyendo node_modules y .next)
log_info "📁 Creando backup de archivos de aplicación..."
tar --exclude='node_modules' \
    --exclude='.next' \
    --exclude='.git' \
    --exclude='*.log' \
    -czf "$BACKUP_DIR/app-backup-$DATE.tar.gz" \
    -C "$(dirname "$APP_DIR")" \
    "$(basename "$APP_DIR")"

log_info "✅ Backup de aplicación completado: app-backup-$DATE.tar.gz"

# Backup de archivos .env (importante para restauración)
if [ -f "$APP_DIR/app/.env" ]; then
    cp "$APP_DIR/app/.env" "$BACKUP_DIR/env-backup-$DATE.txt"
    log_info "✅ Backup de variables de entorno completado: env-backup-$DATE.txt"
fi

# Limpiar backups antiguos
log_info "🧹 Limpiando backups antiguos (más de $RETENTION_DAYS días)..."
find "$BACKUP_DIR" -type f -name "*.sql.gz" -mtime +$RETENTION_DAYS -delete
find "$BACKUP_DIR" -type f -name "*.tar.gz" -mtime +$RETENTION_DAYS -delete
find "$BACKUP_DIR" -type f -name "*.txt" -mtime +$RETENTION_DAYS -delete

# Mostrar estadísticas
TOTAL_BACKUPS=$(ls -1 "$BACKUP_DIR" | wc -l)
BACKUP_SIZE=$(du -sh "$BACKUP_DIR" | cut -f1)

log_info "📈 Estadísticas de backup:"
echo "   - Total de archivos: $TOTAL_BACKUPS"
echo "   - Tamaño total: $BACKUP_SIZE"
echo "   - Ubicación: $BACKUP_DIR"

log_info "✅ ¡Backup completado exitosamente!"

# Opcional: Subir a S3 si está configurado
if [ -n "$BACKUP_S3_BUCKET" ]; then
    log_info "☁️  Subiendo backup a S3..."
    aws s3 sync "$BACKUP_DIR" "s3://$BACKUP_S3_BUCKET/backups/" \
        --exclude "*" \
        --include "*backup-$DATE*" \
        --storage-class STANDARD_IA
    
    log_info "✅ Backup subido a S3: s3://$BACKUP_S3_BUCKET/backups/"
fi

# Opcional: Enviar notificación por email
if [ -n "$BACKUP_EMAIL" ] && command -v mail &> /dev/null; then
    echo "Backup completado exitosamente el $(date)" | \
    mail -s "Backup SaaS Embudos - $(date +%Y-%m-%d)" "$BACKUP_EMAIL"
fi
