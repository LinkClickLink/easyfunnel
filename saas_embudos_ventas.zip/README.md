
# 🚀 SaaS Embudos de Ventas Digitales

Un SaaS completo para crear y gestionar embudos de ventas digitales, orientado a emprendedores que quieren vender productos digitales de forma automatizada.

## ✨ Características Principales

### 🎯 Constructor de Embudos
- Embudo de 3 pasos: Landing → Checkout → Gracias
- Editor visual para personalizar cada página
- Vista previa responsive (desktop, tablet, mobile)
- Configuración de subdominios personalizados

### 📦 Gestión de Productos Digitales
- Subida de archivos (PDF, ZIP, MP4, MP3, JPG, PNG)
- Almacenamiento seguro en AWS S3
- Gestión completa: editar, activar/desactivar, eliminar
- Estadísticas de descargas y almacenamiento

### 👥 CRM Integrado
- Pipeline Kanban: Lead → Prospecto → Cliente → Inactivo
- Gestión de contactos con información detallada
- Búsqueda y filtros avanzados
- Exportación a CSV

### ⚙️ Panel de Configuración
- **Perfil**: Información personal y de negocio
- **Embudo**: Dominios, Analytics, CSS personalizado
- **Pagos**: Integración con Stripe
- **Notificaciones**: Email, SMS, Push
- **Seguridad**: 2FA, timeout de sesión

### 📱 Área de Miembros
- Portal independiente para clientes finales
- Descarga segura de productos comprados
- Límites de descarga configurables
- Interfaz intuitiva y profesional

### 📧 Sistema de Emails
- Plantillas personalizables (bienvenida, compra, descarga)
- Variables dinámicas para personalización
- Editor visual con vista previa

## 🛠️ Stack Tecnológico

- **Frontend**: Next.js 14, React 18, TypeScript
- **Backend**: Next.js API Routes
- **Base de datos**: PostgreSQL con Prisma ORM
- **Autenticación**: NextAuth.js
- **Almacenamiento**: AWS S3
- **Pagos**: Stripe
- **UI**: Tailwind CSS, Framer Motion, Radix UI
- **Emails**: Sistema de plantillas personalizable

## 📋 Requisitos del Sistema

- Node.js 18.0 o superior
- PostgreSQL 12 o superior
- Cuenta AWS con S3
- Cuenta Stripe (para pagos)
- Dominio propio (opcional)

## 🚀 Instalación

### 1. Clona el repositorio
```bash
git clone https://github.com/tu-usuario/saas-embudos-ventas.git
cd saas-embudos-ventas
```

### 2. Instala las dependencias
```bash
cd app
yarn install
```

### 3. Configura las variables de entorno
```bash
cp .env.example .env
```

Edita el archivo `.env` con tus credenciales:

```env
# Base de datos
DATABASE_URL="postgresql://usuario:contraseña@localhost:5432/embudos_ventas"

# NextAuth
NEXTAUTH_URL="https://tu-dominio.com"
NEXTAUTH_SECRET="genera-un-secret-seguro-de-32-caracteres"

# AWS S3
AWS_REGION="us-west-2"
AWS_BUCKET_NAME="tu-bucket-s3"
AWS_ACCESS_KEY_ID="tu-access-key"
AWS_SECRET_ACCESS_KEY="tu-secret-key"

# Stripe
STRIPE_PUBLISHABLE_KEY="pk_live_..."
STRIPE_SECRET_KEY="sk_live_..."
```

### 4. Configura la base de datos
```bash
# Ejecuta las migraciones
yarn prisma migrate deploy

# Genera el cliente Prisma
yarn prisma generate

# (Opcional) Seed de datos iniciales
yarn prisma db seed
```

### 5. Construye el proyecto
```bash
yarn build
```

### 6. Inicia el servidor
```bash
yarn start
```

## 🔧 Configuración Avanzada

### AWS S3 Setup
1. Crea un bucket en S3
2. Configura las políticas de acceso
3. Genera las credenciales IAM
4. Configura CORS si es necesario

```json
[
    {
        "AllowedHeaders": ["*"],
        "AllowedMethods": ["GET", "PUT", "POST", "DELETE"],
        "AllowedOrigins": ["https://tu-dominio.com"],
        "ExposeHeaders": []
    }
]
```

### Base de datos PostgreSQL
```sql
-- Crear base de datos
CREATE DATABASE embudos_ventas;

-- Crear usuario
CREATE USER embudos_user WITH ENCRYPTED PASSWORD 'tu_password_seguro';
GRANT ALL PRIVILEGES ON DATABASE embudos_ventas TO embudos_user;
```

### Configuración Stripe
1. Crea una cuenta en Stripe
2. Obtén las claves API (publishable y secret)
3. Configura los webhooks (opcional)
4. Configura los productos y precios

### Configuración de Email
```env
SMTP_HOST="smtp.gmail.com"
SMTP_PORT="587"
SMTP_USER="tu-email@gmail.com"
SMTP_PASS="tu-app-password"
SMTP_FROM="noreply@tu-dominio.com"
```

## 🚢 Deployment en Producción

### Opción 1: VPS/Servidor Dedicado

#### Usando PM2
```bash
# Instala PM2 globalmente
npm install -g pm2

# Inicia la aplicación
pm2 start yarn --name "embudos-saas" -- start

# Configura para iniciar automáticamente
pm2 startup
pm2 save
```

#### Usando Docker
```bash
# Construye la imagen
docker build -t embudos-saas .

# Ejecuta el contenedor
docker run -d -p 3000:3000 --env-file .env embudos-saas
```

### Opción 2: Vercel (Recomendado)
```bash
# Instala Vercel CLI
npm install -g vercel

# Deploy
vercel --prod
```

### Opción 3: Netlify
```bash
# Instala Netlify CLI
npm install -g netlify-cli

# Build y deploy
yarn build
netlify deploy --prod --dir=out
```

## 🔒 Seguridad

### Recomendaciones importantes:
- Usa HTTPS en producción
- Configura variables de entorno seguras
- Mantén las dependencias actualizadas
- Configura rate limiting
- Usa secrets manager para credenciales sensibles

### Variables de entorno críticas:
```env
NEXTAUTH_SECRET="secret-muy-largo-y-seguro-32-caracteres-minimo"
DATABASE_URL="postgresql://..."
STRIPE_SECRET_KEY="sk_live_..."
AWS_SECRET_ACCESS_KEY="..."
```

## 📊 Monitoreo y Mantenimiento

### Logs importantes:
- Errores de autenticación
- Fallos en pagos
- Subidas de archivos fallidas
- Errores de base de datos

### Tareas de mantenimiento:
- Backup regular de base de datos
- Limpieza de archivos temporales
- Actualización de dependencias
- Monitoreo de uso de S3

## 🐛 Solución de Problemas

### Problemas comunes:

**Error de conexión a base de datos:**
```bash
# Verifica la conexión
yarn prisma db pull
```

**Error de AWS S3:**
```bash
# Verifica credenciales
aws s3 ls s3://tu-bucket
```

**Error de build:**
```bash
# Limpia caché
yarn clean
rm -rf .next
yarn build
```

## 📚 Documentación API

### Endpoints principales:

- `POST /api/products/upload` - Subir producto
- `GET/POST/DELETE /api/products/[id]` - Gestionar productos
- `GET/POST/DELETE /api/contacts/[id]` - Gestionar contactos
- `PATCH /api/settings` - Actualizar configuración
- `POST /api/members/download` - Generar enlace de descarga

## 🤝 Contribuir

1. Fork el proyecto
2. Crea una rama para tu feature (`git checkout -b feature/AmazingFeature`)
3. Commit tus cambios (`git commit -m 'Add some AmazingFeature'`)
4. Push a la rama (`git push origin feature/AmazingFeature`)
5. Abre un Pull Request

## 📄 Licencia

Este proyecto está bajo la Licencia MIT - ver el archivo [LICENSE](LICENSE) para más detalles.

## 📞 Soporte

- 📧 Email: soporte@embudos-digitales.com
- 💬 Discord: [Únete a nuestra comunidad](https://discord.gg/embudos)
- 📖 Documentación: [docs.embudos-digitales.com](https://docs.embudos-digitales.com)

## 🙏 Agradecimientos

- [Next.js](https://nextjs.org/) - Framework de React
- [Tailwind CSS](https://tailwindcss.com/) - Framework CSS
- [Prisma](https://prisma.io/) - ORM para base de datos
- [NextAuth.js](https://next-auth.js.org/) - Autenticación
- [Stripe](https://stripe.com/) - Procesamiento de pagos
- [AWS](https://aws.amazon.com/) - Servicios en la nube

---

⭐ Si este proyecto te ayuda, ¡no olvides darle una estrella!
