
#!/bin/bash

# Script de deployment para servidor propio
set -e

echo "🚀 Iniciando deployment del SaaS Embudos de Ventas..."

# Colores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Variables
APP_NAME="saas-embudos-ventas"
APP_DIR="/var/www/$APP_NAME"
BACKUP_DIR="/var/backups/$APP_NAME"

# Funciones
log_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

log_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Verificar que estamos ejecutando como root o con sudo
if [[ $EUID -ne 0 ]]; then
   log_error "Este script debe ejecutarse como root o con sudo"
   exit 1
fi

# Crear directorio de backup si no existe
mkdir -p $BACKUP_DIR

# Backup de la aplicación actual (si existe)
if [ -d "$APP_DIR" ]; then
    log_info "Creando backup de la aplicación actual..."
    tar -czf "$BACKUP_DIR/backup-$(date +%Y%m%d-%H%M%S).tar.gz" -C "$APP_DIR" .
fi

# Crear directorio de la aplicación
mkdir -p $APP_DIR
cd $APP_DIR

# Clonar el repositorio (o actualizar si ya existe)
if [ -d ".git" ]; then
    log_info "Actualizando repositorio..."
    git pull origin main
else
    log_info "Clonando repositorio..."
    git clone https://github.com/tu-usuario/saas-embudos-ventas.git .
fi

# Instalar dependencias de Node.js
log_info "Instalando dependencias..."
cd app
yarn install --frozen-lockfile

# Construir la aplicación
log_info "Construyendo la aplicación..."
yarn build

# Generar cliente Prisma
log_info "Generando cliente Prisma..."
yarn prisma generate

# Ejecutar migraciones de base de datos
log_info "Ejecutando migraciones de base de datos..."
yarn prisma migrate deploy

# Configurar PM2 si está instalado
if command -v pm2 &> /dev/null; then
    log_info "Configurando PM2..."
    pm2 delete $APP_NAME 2>/dev/null || true
    pm2 start yarn --name $APP_NAME -- start
    pm2 save
else
    log_warn "PM2 no está instalado. Considera instalarlo para gestión de procesos."
fi

# Configurar Nginx si está instalado
if command -v nginx &> /dev/null; then
    log_info "Configurando Nginx..."
    cat > /etc/nginx/sites-available/$APP_NAME << EOF
server {
    listen 80;
    server_name tu-dominio.com www.tu-dominio.com;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_cache_bypass \$http_upgrade;
    }
}
EOF

    ln -sf /etc/nginx/sites-available/$APP_NAME /etc/nginx/sites-enabled/
    nginx -t && systemctl reload nginx
else
    log_warn "Nginx no está instalado. Considera instalarlo como reverse proxy."
fi

log_info "✅ Deployment completado exitosamente!"
echo -e "${GREEN}La aplicación debería estar disponible en: http://tu-dominio.com${NC}"

# Instrucciones post-deployment
echo ""
echo "📋 Próximos pasos:"
echo "1. Configura tu archivo .env con las credenciales correctas"
echo "2. Configura tu dominio en el DNS"
echo "3. Configura SSL con Let's Encrypt (certbot)"
echo "4. Configura monitoreo y backups automáticos"
echo ""
echo "🔧 Comandos útiles:"
echo "pm2 status - Ver estado de la aplicación"
echo "pm2 logs $APP_NAME - Ver logs de la aplicación"
echo "pm2 restart $APP_NAME - Reiniciar la aplicación"
